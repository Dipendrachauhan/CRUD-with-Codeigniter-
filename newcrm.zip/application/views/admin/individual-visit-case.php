<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<!-- JavaScript to show google map -->
 
<div class="inner-wrp">
	<div  class="container-fluid">   
	<div class="row">
			<div class="col-md-12">
				<div id="flipMsg" >
				<?php if($this->session->flashdata('success')){ ?>
						<div class=" alert alert-success"><i class="fa fa-sucess"></i>
							<?php   echo   $this->session->flashdata('success'); ?>
						</div> 
				<?php } ?>	
				<?php   if($this->session->flashdata('error')){ ?>
					<div class=" alert alert-danger"><i class="fa fa-warning"></i>
						<?php   echo   $this->session->flashdata('error'); ?>
					</div> 
				<?php } ?>	
				</div><!--flipMsg-->
			</div>
	 <div class="col-lg-12 col-md-12">
	  <div class="customer-list">
         <div class="frm-heading"><h2>List Customers</h2></div>
          <div class="inner-frm">
          <div class="row">
     <div class="col-lg-12">
	   <table class="table table-bordered table-responsive">
             <thead>	
			  <tr>
				<th>First Name</th>
				<th>Last Name</th>
				<th>Mobile</th>
				<th>Agent Name</th>
				<th>Action</th>				
			  </tr>
           </thead>
			<tbody>
			<?php 
				
				if(!empty($customer_data)){
					
					//$status_user='';
				?>
				<tr>
					<td><?php echo $customer_data['fname']; ?></td>
					<td><?php echo $customer_data['lname']; ?></td>
					<td><?php echo $customer_data['mobile']; ?></td>
					<td><?php echo $customer_data['user_name']; ?></td>
					<td align="center">
						<span class="edit-icon" title="Edit"><a href="<?php echo base_url().'admin/edit_customer/'.$customer_data['id']; ?>" ><img src="<?php echo base_url(); ?>assets/img/icons/edit.png" alt="edit"/></a></span>
						<span class="delete-icon" title="Remove"><a href="<?php echo base_url().'admin/deletecustomer/'.$customer_data['id']; ?>" onclick="return confirm('Are you sure to remove this customer')" ><img src="<?php echo base_url(); ?>assets/img/icons/delete.png" alt="delete"/></a></span>
					</td>
				</tr>
				<?php  
				}	
				else
				{
				?>
					<tr >
					<td style="text-align: center" colspan="8"><?php echo NO_RECORD_MESSAGE; ?></td>
					</tr>
				<?php
				}
				?>
				
			</tbody>
         </table>
		 
		 <div class="frm-heading"><h2>Visit Case</h2></div>
		 <table class="table table-bordered table-responsive">
             <thead>	
			  <tr>
				<th>Customer Name</th>
				<th>Contact Type</th>
				<th>Agent Name</th>
				<th>Visit Date</th>
				<th>Visit Case Note</th>				
				<!--<th>Action</th>				-->
			  </tr>
           </thead>
			<tbody>
			<?php 
				$j=1;
				if(!empty($visit_data)){
					//$status_user='';
					foreach($visit_data as $visit_data){		
			?>
				<tr>
					<td><?php echo $visit_data['vcfname'] . ' ' . $visit_data['vclname']; ?></td>
					<td><?php echo $visit_data['contact_type']; ?></td>
					<td><?php echo $visit_data['user_name']; ?></td>
					<td><?php echo $visit_data['vcdate']; ?></td>
					<td><?php echo $visit_data['vcnote']; ?></td>
					<!--<td align="center">
						<span class="edit-icon" title="Edit"><a href="<?php echo base_url().'admin/edit_customer/'.$visit_data['id']; ?>" ><img src="<?php echo base_url(); ?>assets/img/icons/edit.png" alt="edit"/></a></span>
						<span class="delete-icon" title="Remove"><a href="<?php //echo base_url().'admin/deletecustomer/'.$visit_data['id']; ?>" onclick="return confirm('Are you sure to remove this client?')" ><img src="<?php //echo base_url(); ?>assets/img/icons/delete.png" alt="delete"/></a></span>
					</td>-->
				</tr>
				<?php  
						$j++;
					}
				} 
				if($j==1)
				{
				?>
					<tr >
					<td style="text-align: center" colspan="8"><?php echo NO_RECORD_MESSAGE; ?></td>
					</tr>
				<?php
				}
				?>
			</tbody>
         </table>
          <div class="cl"></div>
          </div><!---innner-frm--->
       </div><!---customer-list-->
     </div>
    </div><!---row--->
          </div><!---innner-frm--->
       </div><!---customer-list-->
	 </div>
	</div>   
	</div>
</div>