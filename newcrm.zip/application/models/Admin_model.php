<?php
class admin_model extends CI_Model {

	public function __construct(){
		$this->load->database();
		}
	
	public function addUsers(){
 
			$dataArray = array();
			$dataArray['user_name'] = $this->input->post('user_name');
			$dataArray['email_id'] = $this->input->post('email');
			$dataArray['first_name'] = $this->input->post('first_name');
			$dataArray['last_name'] = $this->input->post('last_name');
			$dataArray['phone'] = $this->input->post('contact');
			$dataArray['password'] = md5($this->input->post('password'));
			$dataArray['status'] = 1;
			$dataArray['user_role'] = 2;
			 
				 if($this->db->insert('user_login',$dataArray))
						{
							return true;
						}
		}
//edit user
	public function edit_user($user_id){
			$this->db->select('*');
			$this->db->from('user_login');
			$this->db->where('user_id', $user_id);
			$query = $this->db->get();
			$result = $query->result_array();
			return $result;
		}
// Update User

	
	public function update_user($user_id){
			$dataArray = array();
			$dataArray['user_name'] = $this->input->post('user_name');
			$dataArray['email_id'] = $this->input->post('email');
			$dataArray['first_name'] = $this->input->post('first_name');
			$dataArray['last_name'] = $this->input->post('last_name');
			$dataArray['phone'] = $this->input->post('contact');
			$dataArray['password'] = md5($this->input->post('password'));
			$dataArray['status'] = 1;
			$dataArray['user_role'] = 2;
			$this->db->where('user_id', $user_id);
            
			if($this->db->update('user_login',$dataArray)); 
				{
							return true;
				}
		}
//Delet User 

	public function did_delete_row($id){
		  $this -> db -> where('user_id', $id);
		  $this -> db -> delete('user_login');
		  redirect($_SERVER['HTTP_REFERER']);
	}
//add customers

	public function addcustomers(){
 
		$dataArray = array();
		
		$dataArray['fname'] = $this->input->post('first_name');
		$dataArray['lname'] = $this->input->post('last_name');
		$dataArray['desire_date'] = $this->input->post('desire_date');
		$dataArray['living_status'] = $this->input->post('living_status');
		if(array_key_exists("rlreason",$this->input->post())){
		$dataArray['rlreason'] = implode(",", $this->input->post('rlreason'));
		}else{
		$dataArray['rlreason'] = '';
		}
		
		$dataArray['follow_up_date'] = date('Y-m-d',strtotime($this->input->post('follow_up_date')));
		$dataArray['hear_about'] = $this->input->post('hear_about');
		$dataArray['phome'] = $this->input->post('phome');
		$dataArray['mobile'] = $this->input->post('mobile');
		$dataArray['pbusiness'] = $this->input->post('pbusiness');
		$dataArray['fax'] = $this->input->post('fax');
		$dataArray['street'] = $this->input->post('street');
		$dataArray['city'] = $this->input->post('city');
		$dataArray['state'] = $this->input->post('state');
		$dataArray['zip'] = $this->input->post('zcode');
		$dataArray['country'] = $this->input->post('country');
		$dataArray['user_name'] = $this->session->userdata('user_name');


			if($this->db->insert('customers',$dataArray))
					{
			$caseData = array();
			$caseData['customer_id'] = $this->db->insert_id();
			$caseData['vcfname'] = $this->input->post('first_name');
			$caseData['vclname'] = $this->input->post('last_name');
			$caseData['contact_type'] = $this->input->post('contact_type');
			$caseData['user_name'] = $this->session->userdata('user_name');
			$caseData['vcdate'] = $this->input->post('vcdate');
			$caseData['vcnote'] = $this->input->post('vcnote');
	                $caseData['hear_about'] = $this->input->post('hear_about');
			if(array_key_exists("rlreason",$this->input->post())){
			$caseData['rlreason'] = implode(",", $this->input->post('rlreason'));
			}else{
			$caseData['rlreason'] = '';
			}
			
			if(!empty($caseData['contact_type']) && !empty($caseData['vcnote'])){
				if($this->db->insert('visite_case',$caseData));
					{
					return true;
					}
				}
				else
				{
				return true;
				}
			}
		}
//edit user
	public function edit_customer($id){
			$this->db->select('*');
			$this->db->from('customers');
			$this->db->where('id', $id);
			$query = $this->db->get();
			$result = $query->result_array();
			return $result;
		}

	public function update_customer($id){
		
		$dataArray = array();
		$dataArray['fname'] = $this->input->post('first_name');
		$dataArray['lname'] = $this->input->post('last_name');
		$dataArray['desire_date'] = $this->input->post('desire_date');
		$dataArray['living_status'] = $this->input->post('living_status');
		if(array_key_exists("rlreason",$this->input->post())){
		$dataArray['rlreason'] = implode(",", $this->input->post('rlreason'));
		}else{
		$dataArray['rlreason'] = '';
		}
		$dataArray['follow_up_date'] = date('Y-m-d',strtotime($this->input->post('follow_up_date')));
		$dataArray['hear_about'] = $this->input->post('hear_about');
		$dataArray['phome'] = $this->input->post('phome');
		$dataArray['mobile'] = $this->input->post('mobile');
		$dataArray['pbusiness'] = $this->input->post('pbusiness');
		$dataArray['fax'] = $this->input->post('fax');
		$dataArray['street'] = $this->input->post('street');
		$dataArray['city'] = $this->input->post('city');
		$dataArray['state'] = $this->input->post('state');
		$dataArray['zip'] = $this->input->post('zcode');
		$dataArray['country'] = $this->input->post('country');
		$dataArray['user_name'] = $this->session->userdata('user_name');
		
		$this->db->where('id', $id);

			if($this->db->update('customers',$dataArray))
			{
			//$id= $id;
			
			$caseData = array();
			$caseData['customer_id'] = $id;
			$caseData['vcfname'] = $this->input->post('first_name');
			$caseData['vclname'] = $this->input->post('last_name');
			$caseData['contact_type'] = $this->input->post('contact_type');
			$caseData['user_name'] = $this->session->userdata('user_name');
			$caseData['vcdate'] = $this->input->post('vcdate');
			$caseData['vcnote'] = $this->input->post('vcnote');
            $caseData['hear_about'] = $this->input->post('hear_about');
			if(array_key_exists("rlreason",$this->input->post())){
			$caseData['rlreason'] = implode(",", $this->input->post('rlreason'));
			}else{
			$caseData['rlreason'] = '';
			}
			
			if(!empty($caseData['contact_type']) && !empty($caseData['vcnote'])){
				if($this->db->insert('visite_case',$caseData));
						{
						
						$this->db->where('customer_id', $id);
                        $this->db->update('visite_case', array('rlreason'=>$caseData['rlreason'],'hear_about'=>$caseData['hear_about'])); 
						return true;
						}
			} else {
			return true;
			}
		}	
	}
//delete customer		
	public function customer_delete_row($id){
		
			$this -> db -> where('id', $id);
			if($this -> db -> delete('customers')){
				$this -> db -> where('customer_id', $id);
				$this -> db -> delete('visite_case');
				redirect('admin/listcustomers', '');
			}
		} 
	public function get_client_by_range($limit, $start){
			$this->db->select('*');
			$this->db->from('user_login');
			$this->db->where('user_role !=', '1');
			$this->db->order_by('user_id', 'DESC');
			$this->db->limit($limit, $start);
			$query = $this->db->get();
			return $query->result_array();
		}
	public function get_count_clients(){
		$this->db->select('*');
		$this->db->from('user_login');
		
		$this->db->where('user_role !=', '1');
		$this->db->order_by('user_id', 'DESC');
		$query = $this->db->get();
		return $query->num_rows();
	}
	public function get_customers_by_range($limit, $start){
		$this->db->select('*');
		$this->db->from('customers');
		$this->db->order_by('id', 'DESC');
		$this->db->limit($limit, $start);
		$query = $this->db->get();
		return $query->result_array();
	}
	public function get_count_customers(){
		$this->db->select('*');
		$this->db->from('customers');
		
		$this->db->order_by('id', 'DESC');
		$query = $this->db->get();
		return $query->num_rows();
	}
	
	public function get_visitcase_by_range($limit, $start){
		$this->db->select('*');
		$this->db->from('visite_case');
		$this->db->order_by('id', 'DESC');
		$this->db->limit($limit, $start);
		$query = $this->db->get();
		return $query->result_array();
	}
	public function get_count_visitcase(){
		$this->db->select('*');
		$this->db->from('visite_case');
		$this->db->order_by('id', 'DESC');
		$query = $this->db->get();
		return $query->num_rows();
	}
	
	public function search_customer($search = null){
		
		$searchdata = explode(' ',$search);
		$f = '';
		$l = '';
		if(count($searchdata) == 1){
			$f = $searchdata[0];
		}
		if(count($searchdata) > 1){
		 $f = $searchdata[0];
		 $l = $searchdata[1];
		}
		$this->db->select('*');
		$this->db->from('customers');
		$this->db->where('fname', $f);
		$query = $this->db->get();
		
		return $query->result_array();
		
	}
	public function view_visit_case_individual($id){
	   $this->db->select('*');
		$this->db->from('customers');
		$this->db->where('id', $id);
		$query = $this->db->get();
		
		return $query->row_array();
	}
	public function visit_data($customerid = null){
		
		
		$this->db->select('*');
		$this->db->from('visite_case');

		$this->db->where('customer_id',$customerid);
                $this->db->order_by('id', 'DESC');
		$query = $this->db->get();
		return $query->result_array();
	}
	public function ajax_data($firstname = null,$param = null){
		
		
		$this->db->select('*');
		$this->db->from('customers');
		if($param == 'fname'){
        $this->db->like('fname', $firstname,'after');
}else{$this->db->like('lname', $firstname,'after');	}	
		$query = $this->db->get();
		return $query->result_array();
	}
	public function ajax_databox($search = null){
		
		
		$this->db->select('*');
		$this->db->from('customers');
        $this->db->like('fname', $search);  
		$this->db->or_like('lname', $search); 
		$query = $this->db->get();
		return $query->result_array();
	}
	
	public function ajax_data_complete($id = null){
		
		
		$this->db->select('*');
		$this->db->from('customers');
        $this->db->where('id', $id); 
		$query = $this->db->get();
		return $query->result_array();
	}
	
	public function update_edit_customer($id){
		
		$dataArray = array();
		$dataArray['id'] = $this->input->post('id');
		$dataArray['fname'] = $this->input->post('first_name');
		$dataArray['lname'] = $this->input->post('last_name');
		$dataArray['desire_date'] = $this->input->post('desire_date');
		$dataArray['living_status'] = $this->input->post('living_status');
		if(array_key_exists("rlreason",$this->input->post())){
		$dataArray['rlreason'] = implode(",", $this->input->post('rlreason'));
		}else{
		$dataArray['rlreason'] = '';
		}
		$dataArray['follow_up_date'] = date('Y-m-d',strtotime($this->input->post('follow_up_date')));
		$dataArray['hear_about'] = $this->input->post('hear_about');
		$dataArray['phome'] = $this->input->post('phome');
		$dataArray['mobile'] = $this->input->post('mobile');
		$dataArray['pbusiness'] = $this->input->post('pbusiness');
		$dataArray['fax'] = $this->input->post('fax');
		$dataArray['street'] = $this->input->post('street');
		$dataArray['city'] = $this->input->post('city');
		$dataArray['state'] = $this->input->post('state');
		$dataArray['zip'] = $this->input->post('zcode');
		$dataArray['country'] = $this->input->post('country');
		$dataArray['user_name'] = $this->session->userdata('user_name');
		//echo "<pre>";
				//	print_r($dataArray);die;
		$this->db->where('id', $id);
		
				if($this->db->update('customers',$dataArray, array('id' => $_POST['id'])))
				{
					
				$caseData = array();
				$caseData['customer_id'] = $this->input->post('id');
				$caseData['vcfname'] = $this->input->post('first_name');
				$caseData['vclname'] = $this->input->post('last_name');
				$caseData['contact_type'] = $this->input->post('contact_type');
				$caseData['user_name'] = $this->session->userdata('user_name');
				$caseData['vcdate'] = $this->input->post('vcdate');
				$caseData['vcnote'] = $this->input->post('vcnote');
				$caseData['hear_about'] = $this->input->post('hear_about');
			      if(array_key_exists("rlreason",$this->input->post())){
			     $caseData['rlreason'] = implode(",", $this->input->post('rlreason'));
			     }else{
			     $caseData['rlreason'] = '';
			    }	
				$this->db->where('customer_id', $id);
				if(!empty($caseData['contact_type']) && !empty($caseData['vcnote'])){
					if($this->db->insert('visite_case',$caseData));
							{
					//echo "<pre>";
					//print_r($caseData);die;
								
							return true;
							}
				} else {
					return true;
				}
		}
	}

          public function crontest($current){
	
		$this->db->select('*');
		$this->db->where('follow_up_date', $current);
		$q = $this->db->get('customers');
		$data = $q->result_array();
      
 		return $data;
	}
	
			public function create_csv(){
			$query = $this->db->query('SELECT * FROM visite_case');
            $num = $query->num_fields();
            $var =array();
            $i=1;
            $vcfname="";
            while($i <= $num){
                $test = $i;
                $value = $this->input->post($test);

                if($value != ''){
                        $vcfname= $vcfname." ".$value;
                        array_push($var, $value);
                    }
                 $i++;
            }

            $vcfname = trim($vcfname);
			
            $vcfname=str_replace(' ', ',', $vcfname);

            $this->db->select($vcfname);
            $quer = $this->db->get('visite_case');
            return $quer;
			}

}