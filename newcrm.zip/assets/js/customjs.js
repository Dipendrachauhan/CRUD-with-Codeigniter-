// Global variables starts. 
var mandatory_field = "You can't leave this empty.";
var mandatory_fields_msg = "Please fill up all the required form fields.";
var valid_email = "Please enter valid Email Id.";
// Global variables ends. 

var pageUrlG = "localhost/getdel/";
/*
 * 
 * Update Email of Client as same as Username 
 * 
 */

function updateEmailField(val)
{
	$("#email").val(val);
}

	/*
 * 
 * Get latitude and longitude of client address
 * 
 */


	function getLatLong(){
		var concat_address='';
		var address = $("#address").val();
		if(address!=''){
			concat_address+=address+', ';
		}
		var city = $("#city").val();
		if(city!=''){
			concat_address+=city+', ';
		}
		var zipcode = $("#zipcode").val();
		if(zipcode!=''){
			concat_address+=zipcode+', ';
		}
		var state = $("#state").val();
		if(state!=''){
			concat_address+=state+', ';
		}
		var country = $("#country").val();
		if(country!=''){
			concat_address+=country;
		}
		var geocoder = new google.maps.Geocoder();
		geocoder.geocode({ 'address': concat_address}, function(results, status) 
		{
			if (status == google.maps.GeocoderStatus.OK) {
				var latitude = results[0].geometry.location.lat();
				var longitude = results[0].geometry.location.lng();
				
				$("#latitude").val(latitude);
				$("#longitude").val(longitude);
				var myOptions = {
					zoom: 14,
					center: new google.maps.LatLng(latitude, longitude),
					mapTypeId: google.maps.MapTypeId.ROADMAP
				};
				map = new google.maps.Map(document.getElementById("gmap_canvas"), myOptions);
				marker = new google.maps.Marker({
					map: map,
					position: new google.maps.LatLng(latitude, longitude)
				});
				
				google.maps.event.addListener(marker, "click", function () {
					infowindow.open(map, marker);
				});
				infowindow.open(map, marker);
				google.maps.event.addDomListener(window, 'load', init_map);
			}
		}); 
	}


/*
 * 
 * Change admin status 
 * 
 */

function changeStatus(id)
{
    var pageUrl = $("#url").val();
    $.ajax({
        url: pageUrl + 'admin/changeStatus',
        type: 'POST',
        data: {id: id},
        success: function(msg)
        {
            //alert(msg);
            if (msg === 1) ;
            window.location.href = pageUrl + 'admin/list_admin';
        }
    });
}


/*
 * 
 *Check file name
 * 
 * 
 */

function validateImage(filename)
{
   
  var ext = filename.split('.').pop();
 if(ext=='jpeg' || ext=='jpg' || ext=='png' )
     {
         return true;
     }
     else{
       //  $("#userfile_error").text('File type mismatch');
         return false;
     }

}




/*
 * 
 * Get country  id
 * 
 */

function getCountryId()
{
    var id = $("#country").find("option:selected").prop("value");
    var pageUrl = $("#url").val();
    $.ajax({
        url: pageUrl + 'property/getAllStates',
        type: 'POST',
        data: {id: id},
        success: function(msg)
        {
            // alert(msg);
            $("#state").html(msg);
        }
    });
}

/*
 * 
 * Get state id 
 * 
 */

function getStateId()
{
    var id = $("#state").find("option:selected").prop("value");
    var pageUrl = $("#url").val();
    $.ajax({
        url: pageUrl + 'Propertyapplication/getAllCities',
        type: 'POST',
        data: {id: id},
        success: function(msg)
        {
           // alert(msg);
            $("#city").html(msg);


        }
    });
}

/*
 * 
 * Change application status 
 * 
 */

function changeApplicationStatus(id)
{
    var pageUrl = $("#url").val();
    $.ajax({
        url: pageUrl + 'propertyapplication/changeapplicationstatus',
        type: 'POST',
        data: {id: id},
        success: function(msg)
        {
            if (msg === 1)
                ;
            window.location.href = pageUrl + 'propertyapplication/list_application';
        }
    });
}

/*
 * 
 * Change property status 
 * 
 */

function changePropertyStatus(id)
{
    var pageUrl = $("#url").val();
    $.ajax({
        url: pageUrl + 'property/changePropertyStatus',
        type: 'POST',
        data: {id: id},
        success: function(msg)
        {
            //alert(msg);
            if (msg === 1)
                ;
            window.location.href = pageUrl + 'property/list_property';
        }
    });
}

/*
 * 
 * Get subscription id 
 * 
 */

function getSubscriptionId(id)
{
    var pageUrl = $("#url").val();
    $.ajax({
        url: pageUrl + 'property/paymentSubscriptionHistory',
        type: 'POST',
        data: {id: id},
        success: function(msg)
        {
            // alert(msg);
            if (msg === 1)
                ;
            window.location.href = pageUrl + 'property/subscriptionhistory';
        }
    });
}
/*
 * 
 * Change PMC status  
 * 
 * 
 */
function getPmcId(id)
{
    var pageUrl = $("#url").val();
    $.ajax({
        url: pageUrl + 'pmc/changePmcStatus',
        type: 'POST',
        data: {id: id},
        success: function(msg)
        {

            if (msg === 1)
                ;
            window.location.href = pageUrl + 'pmc/view_pmcs';
        }
    });
}


/*
 * 
 * Change tenant status
 * 
 * 
 */
function getTenantId(id)
{
    var pageUrl = $("#url").val();
    $.ajax({
        url: pageUrl + 'tenant/changeTenantStatus',
        type: 'POST',
        data: {id: id},
        success: function(msg)
        {
            if (msg === 1)
                ;
            window.location.href = pageUrl + 'tenant/list_tenant';
        }
    });
}

/*
 * 
 * Get field value 
 * 
 * 
 */


function getData(pmcname)
{
    var pageUrl = $("#url").val();
    $.ajax({
        url: pageUrl + 'tenant/getTenants',
        type: 'POST',
        data: {pmcname: pmcname},
        success: function(msg)
        {
            //  alert(msg);

        }
    });
}

/*
 * 
 * Validates fields on form submit.
 * Added on : 25-01-2016
 * alert
 */

function checkOnFormSubmit(arrArg) {

    var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    var intRegex = /^\d+$/;
    var urlRegex = /^(ht|f)tps?:\/\/[a-z0-9-\.]+\.[a-z]{2,4}\/?([^\s<>\#%"\,\{\}\\|\\\^\[\]`]+)?$/;
    var errors = "";
    var count = 0;
    var ifErrMsg = "";
    var password="";
    $.each(arrArg, function(index, id){
        var checkVal = $("#" + id).attr("check");
        var allChecks = checkVal.split("||");
        $.each(allChecks, function(index, check) {
            ifErrMsg = $.trim($("#" + id + "_error").html());
            $("#" + id + "_error").hide().html("");
            if (check == 'req'){
                if ($.trim($("#" + id).val()) == "") {
                    errors = mandatory_field + " <br>";
                    if (ifErrMsg != "") {
                        errors = ifErrMsg + "";
                    } else {
                        errors = mandatory_field + " <br>";
                    }
                }
            }

            if (check == 'req0') {
                if ($.trim($("#" + id).val()) == "" || $.trim($("#" + id).val()) == "0") {
                    if (ifErrMsg != "") {
                        errors = ifErrMsg + "";
                    } else {
                        errors = mandatory_field + " <br>";
                    }
                }
            }
             
              if (check == 'first_name')
              {
                if ($.trim($("#" + id).val()) == "") {
                    errors = mandatory_field + " <br>";
                }
                var first_name = $('#' + id).val();
                if (first_name) {
                    var length = $('#' + id).val().length;
                    if (length >15) {
                        errors = "First name is not greater than 15 characters <br>";
                    }
                }
            }
              if (check == 'last_name')
              {
                
                var last_name = $('#' + id).val();
                if (last_name) {
                    var length = $('#' + id).val().length;
                    if (length >15) {
                        errors = "Last name is not greater than 15 characters <br>";
                    }
                }
            }
             
             if (check == 'zip_code')
              {
                var zip_code = $('#' + id).val();
                if (zip_code) {
                    var length = $('#' + id).val().length;
                    if (length >12) {
                        errors = "Zip code is not greater than 12 characters <br>";
                    }
                }
            }
               if (check == 'max_tenant') {
                if (!intRegex.test($("#" + id).val())) {
                    if (ifErrMsg != "") {
                        errors = ifErrMsg + "";
                    } else {
                        errors = valid_number + " <br>";
                    }
                }
            }
            
            
            if (check == 'email') {
                if ($.trim($("#" + id).val()) == "") {
                    errors = mandatory_field + " <br>";
                } else if (!regex.test(($("#" + id).val()))) {
                    errors = errors + valid_email + " <br>";
                }
            }



            if (check == 'password') {
                 
                password = $('#' + id).val();
              
                if (password) {
                    var length = $('#' + id).val().length;
                    if (length < 6) {
                        errors = "Password should have atleast 6 characters <br>";
                    }
                }
            }
             if (check =='cpassword')
             {
               var cpassword = $('#' + id).val();
                if(password!=cpassword)
                    {
                        errors = "Password and confirm password does not match <br>";
                    }
                if (cpassword) {
                    var length = $('#' + id).val().length;
                    if (length < 6) {
                        errors = "Confirm password should have atleast 6 characters <br>";
                    }
                }
            }
            if (check =='userfile')
             {
                 var filedata=$("#userfile").val();
                 if(filedata!='')
                 {
                 var ext = filedata.split('.').pop();
                if(ext=='jpeg' || ext=='jpg' || ext=='png' )
                    {
                        return true;
                    }
                    else{
                      errors = "File type mismatch";
                        return false;
                    }
                   }
            }
            if (check == 'url') {
                if (!urlRegex.test(($("#" + id).val()))) {
                    if (ifErrMsg != "") {
                        errors = ifErrMsg + " <br>";
                    } else {
                        errors = valid_url + " <br>";
                    }
                }
            }

            if (check == 'number') {
                if (!intRegex.test($("#" + id).val())) {
                    if (ifErrMsg != "") {
                        errors = ifErrMsg + "";
                    } else {
                        errors = valid_number + " <br>";
                    }
                }
            }

            if (check.indexOf("req_check") >= 0) {
                var allChecksTerm = check.split("+");
                if (!$('#' + id).is(':checked')) {
                    errors = errors + allChecksTerm[1] + " <br>";
                }
            }
         //   alert(count);
            

        });
        
        if (errors != "") {
            $("#" + id + "_error").show().html(errors);
            count = count + 1;
        }
        errors = "";
    });
    
    //alert(count);
    if (count == 0) {
        return true;
    }else if (count > 0) {
        $("#dialog-confirm-message_title").html("Error");
        //$('#dialog-confirm-message_content').html(mandatory_fields_msg);
      //  $('#dialog-confirm-message').modal('show');
       // $("#dialog-confirm-message").click(function(event) {
          //  event.stopImmediatePropagation();
       // });
//        alert(mandatory_fields_msg);
    }
   // alert("yooo");
    return false;
}

function checktinymce(editor){
var editorContent = tinyMCE.get(editor).getContent();
if (editorContent == ''){
    alert("koo");
    // Editor empty
}
else
{
   alert("pooo"); // Editor contains a value
}
return false;
}

function validateInputField(id, type_of_data) {
    var reg_expn;
    if (id && type_of_data) {
        if (type_of_data == 'numeric') {
            reg_expn = /[`~!@#$%^&*()_|a-z+\-=?;:'".<>\{\}\[\]\\\/]/gi;
        } else if (type_of_data == 'alphanumeric') {
            reg_expn = /[`~!@#$%^&*()_|+\-=?;:'".<>\{\}\[\]\\\/]/gi;
        } else if (type_of_data == 'alphabetic') {
            reg_expn = /[`~!@#$%^&*()_|0-9+\-=?;:'".<>\{\}\[\]\\\/]/gi;
        }
        var value = $("#" + id).val();
        var isSplChar = reg_expn.test(value);
        if (isSplChar)
        {
            var no_spl_char = value.replace(reg_expn, '');
            $("#" + id).val(no_spl_char);
            return false;
        } else {
            return true;
        }
    }
}


function checkForTotalChars(id, chars_count, typeOfData, isMandatory) {

    if (id != '' && chars_count != '' && typeOfData != '') {
        $("#" + id + "_error").hide().html("");
        var elementData = $("#" + id).val();
        if (elementData && elementData != '') {
            if (getTotalCharsCount(id) == chars_count) {
                return true;
            } else {
                $("#" + id + "_error").show().html("Please enter atleast " + chars_count + " " + typeOfData + ".");
                return false;
            }
        } else {
            if (isMandatory) {
                $("#" + id + "_error").show().html(mandatory_field);
                return false;
            } else {
                return true;
            }
        }

    }
}

function maxDigitsLimit(id, digitsLimit, errorId) {
    $('#' + errorId + '_error').hide().html('');
    if (id && digitsLimit) {

        var max = parseInt(digitsLimit);
        if (validateInputField(id, "numeric")) {
            var numVal = $('#' + id).val();

            if (numVal && $.isNumeric(numVal)) {

                var len = numVal.length;
                if (len > max) {
                    $('#' + id).val(numVal.substring(0, max));
                    return false;
                } else {
                    return true;
                }
            }
        }
    }

}


/*
 * Function getTotalCharsCount()
 * Parameter 1,String.
 * Gives total characters in the input field.
 * Date: 25-Jan-2016
 * Author :Sanjay Chaudhary
 * Return Type : integer
 */
function getTotalCharsCount(id) {
    if (id != '') {
        var total_chars = $("#" + id).val().length;
        return total_chars;
    }
}

/*
 * 
 * Set payment for tenant ach and cc
 * 
 * 
 */
         function getStatusTenant(id)
         {
           //alert(id);
           if(id==1)
               {
             $(".ccachDiv").show("fast");
              
               }
               else{
                    $(".ccachDiv").hide("fast");
               }
         }
/*
 * 
 * 
 * Delete All messages
 * 
 * 
 */ 

function checkAll(value)
{
    var alldata='';
    if(value==1)
    {
        $('.checkAll').each(function(){
               if(this.checked != true){
                    alert("Select all checkbox");
               }
          });

    }
    if(value==2)
        {
            $('.checkAll').each(function() 
            {
               if(this.checked != true)
               {
                  alert("Select all checkbox");
               }
               else{
                    var chkBoxvalue = '';
                    $('.checkAllValue:checked').each(function() {
                        chkBoxvalue=chkBoxvalue+($(this).val())+",";
                    });
                    
                    if(confirm('Are you sure want to delete record ?'))
                    {
                    chkBoxvalue= chkBoxvalue.replace(/^,|,$/g,'');
                    var pageUrl = $("#url").val();
                    $.ajax({
                        url: pageUrl + 'message/deleteallMessages',
                        type: 'POST',
                        data: {chkBoxvalue: chkBoxvalue},
                        success: function(msg)
                        {
                            //alert(msg);
                           if(msg==1)
                               {
                                   window.location.href = pageUrl + 'message/list_message';
                               }
                           
                        }
                    });
                  }
                     else{
                      
                        return false;
                    }
                    
                    
                    
                 
               }
               
            });
        }
   
    
}
/*
 * 
 * Validate form approve/reject
 * 
 * 
 */

function validateFormSubmit()
{

   var pmc_name=$("#company_name").val();
   var status=$("#status").val();
   var setup_charge=$("#setup_charge").val();
   var firstdata_api_cc=$("#firstdata_api_cc").val();
   var firstdata_api_ach=$("#firstdata_api_ach").val();
   var firstdata_fee_cc=$("#firstdata_fee_cc").val();
   var firstdata_fee_ach=$("#firstdata_fee_ach").val();
   var firstdata_fee_amex_cc=$("#firstdata_fee_amex_cc").val();
   var date_of_start=$("#date_of_start").val();
   var first_due_date=$("#first_due_date").val();
   var monthly_rate=$("#monthly_rate").val();
   var contract_doc1=$("#contract_doc1").val();
   var contract_doc2=$("#contract_doc2").val();

   if(pmc_name=='')
       {
           $("#company_name_error").html(mandatory_field);
           return false;
       }
       if(status=='')
       {
           $("#status_error").html(mandatory_field);
           return false;
       }
        if(setup_charge=='')
       {
           $("#setup_charge_error").html(mandatory_field);
           return false;
       }
        if(firstdata_api_cc=='')
       {
           $("#firstdata_api_cc_error").html(mandatory_field);
           return false;
       }
        if(monthly_rate=='')
       {
           $("#monthly_rate_error").html(mandatory_field);
           return false;
       } if(firstdata_api_ach=='')
       {
           $("#firstdata_api_ach_error").html(mandatory_field);
           return false;
       } if(firstdata_fee_cc=='')
       {
           $("#firstdata_fee_cc_error").html(mandatory_field);
           return false;
       } if(firstdata_fee_amex_cc=='')
       {
           $("#firstdata_fee_amex_cc_error").html(mandatory_field);
           return false;
       } if(firstdata_fee_ach=='')
       {
           $("#firstdata_fee_ach_error").html(mandatory_field);
           return false;
       } if(date_of_start=='')
       {
           $("#date_of_start_error").html(mandatory_field);
           return false;
       } if(first_due_date=='')
       {
           $("#first_due_date_error").html(mandatory_field);
           return false;
       }

        if(contract_doc1!='')
        {
        var ext = contract_doc1.split('.').pop();
         if(ext=='doc' || ext=='pdf' || ext=='xlsx' || ext=='docx')
           {
               return true;
           }
           else{
            $("#contract_doc1_error").html( "File type mismatch");
               return false;
           }
          }
         if(contract_doc2!='')
        {
        var ext2 =contract_doc2.split('.').pop();
        if(ext2=='doc' || ext2=='pdf' || ext2=='xlsx' || ext2=='docx' )
           {
               return true;
           }
           else{
            $("#contract_doc2_error").html( "File type mismatch");
               return false;
           }
          }
        
                 
      
}
