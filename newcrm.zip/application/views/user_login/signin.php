<?php
defined('BASEPATH') OR exit('No direct script access allowed');
if (isset($this->session->userdata['user_id'])) {

 redirect('admin/dashboard');
}

   
?>
<!DOCTYPE html>
<html>
  <head>
    <title>CRM | <?php echo $title;?></title>
    <meta charset="utf-8">
	<meta name="format-detection" content="telephone=no">
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />

	<!---css----->
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/style-sheet.css"/>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/font/styles-font-calibri.css"/>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/bootstrap-3.3.6-dist/css/bootstrap.css"/>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/font-awesome-4.5.0/css/font-awesome.css"/>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/styles-nav.css"/>

	<!---css end----->

	<!--script--->
	<script type="text/javascript" src="<?php echo base_url();?>assets/js/jquery-2.2.0.min.js"></script>
	<script type="text/javascript" src="<?php echo base_url();?>assets/js/script.js"></script>
	<script type="text/javascript" src="<?php echo base_url();?>assets/bootstrap-3.3.6-dist/js/bootstrap.js"></script>
	<style>
     body{ background: rgba(0, 0, 0, 0) url("<?php echo base_url();?>assets/img/login-bg.jpg") no-repeat scroll center center / 100% auto;}
	 .error{background-color: red;margin-top: 5px; color: #fff; }  
     .success{background-color: green;margin-top: 5px;color: #fff;}
     #flipMsg{  margin-left: 0px;padding-top: 2px;margin-bottom: 12px;text-align: center;}    
    </style>
	<script>
	$(document).ready(function(){
		setTimeout(function(){$("#flipMsg").slideUp('fast'); }, 10000);
	});
  </script>
</head>
  <body>
    <div class="login-page-wrp">
		<div class="row">	
			<div class="login-frm">
			<div id="flipMsg">
				<?php if(isset($_GET['permission'])){ ?>
					<div class="alert alert-danger messageBoxHeight">
						<?php echo PERMISSION_ACCESS; ?>
					</div>
			   <?php } ?> 
			   <?php if( $this->session->flashdata('error')) { ?>
				   <div class="alert alert-danger messageBoxHeight">
				   <?php   echo $this->session->flashdata('error');
						$this->session->unset_userdata('error');
				   ?>
				   </div>
				<?php } ?>
				<?php if($this->session->flashdata('message')){ ?>
					<div class="alert alert-success messageBoxHeight">
					 <?php echo $this->session->flashdata('message'); ?>
					</div>
				<?php } ?>
				</div>
			  <?php
				 echo form_open('user_login/login');?>
				  <div class="form-group">
				  <label for="username">Username</label>
					<input type="text" name="username" id="username" value="<?php echo set_value('username');?>" class="form-control" placeholder="Username">
				   <?php echo form_error('username', '<div class="alert alert-danger messageBoxHeight">', '</div>'); ?>
					<span class="glyphicon glyphicon-envelope form-control-feedback"></span>
				  </div>
				  <div class="form-group">
				  <label for="password">Password</label>
					<input type="password" class="form-control" id="password" name="password" placeholder="Password">
					 <?php echo form_error('password', '<div class="alert alert-danger messageBoxHeight">', '</div>'); ?>
					<span class="glyphicon glyphicon-lock form-control-feedback"></span>
				  </div>
				 <button type="submit" class="btn btn-info btn-block login">Submit</button>
			   <?php echo form_close();?>
				<!--<a href="<?php echo base_url().'user_login/reset_password'?>">Forgot Password</a><br>-->
			   </div>
		  </div>
     </div>
  <!--<footer class="bg_footer">
   <div class="container-fluid">
   <div class="col-lg-12">
     <p class="text-center">Copyright © 2016 All Rights Reserved.<br/>Designed By CRM Inc.</p>
   </div>
   </div>
 </footer>-->
  </body>
</html>