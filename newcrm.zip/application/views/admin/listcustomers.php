<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<!-- JavaScript to show google map -->
 
<div class="inner-wrp">
	<div  class="container-fluid">   
	<div class="row">
			<div class="col-md-12">
				<div id="flipMsg" >
				<?php if($this->session->flashdata('success')){ ?>
						<div class=" alert alert-success"><i class="fa fa-sucess"></i>
							<?php   echo   $this->session->flashdata('success'); ?>
						</div> 
				<?php } ?>	
				<?php   if($this->session->flashdata('error')){ ?>
					<div class=" alert alert-danger"><i class="fa fa-warning"></i>
						<?php   echo   $this->session->flashdata('error'); ?>
					</div> 
				<?php } ?>	
				</div><!--flipMsg-->
			</div>
	 <div class="col-lg-12 col-md-12">
	  <div class="customer-list">
         <div class="frm-heading"><h2>List Customers</h2></div>
          <div class="inner-frm">
          <div class="row">
     <div class="col-lg-12">
	 
       <div class="customer-list-table">
          <div class="inner-customer-tbl table-responsive">
           <table class="table table-bordered table-responsive">
             <thead>	
			  <tr>
				<th>First name</th>
				<th>Last name</th>
				<th>Mobile</th>
				<th>Added By</th>
				<th>Action</th>				
			  </tr>
           </thead>
			<tbody>
			<?php 
				$i=1;
				
				if(!empty($customers)){
					
					//$status_user='';
					foreach($customers as $customers){
						
			?>
				<tr>
					<td><?php echo $customers['fname']; ?></td>
					<td><?php echo $customers['lname']; ?></td>
					<td><?php echo $customers['mobile']; ?></td>
					<td><?php echo $customers['user_name']; ?></td>
					<td align="center">
						<span class="edit-icon" title="Edit"><a href="<?php echo base_url().'admin/edit_customer/'.$customers['id']; ?>" ><img src="<?php echo base_url(); ?>assets/img/icons/edit.png" alt="edit"/></a></span>
						<span class="delete-icon" title="Remove"><a href="<?php echo base_url().'admin/deletecustomer/'.$customers['id']; ?>" onclick="return confirm('Are you sure to remove this client?')" ><img src="<?php echo base_url(); ?>assets/img/icons/delete.png" alt="delete"/></a></span>
					</td>
				</tr>
				<?php  
						$i++;
					}
				} 
				if($i==1)
				{
				?>
					<tr >
					<td style="text-align: center" colspan="8"><?php echo NO_RECORD_MESSAGE; ?></td>
					</tr>
				<?php
				}
				?>
				
			</tbody>
         </table>
          
          <div class="cl"></div>
          </div><!---innner-frm--->
       </div><!---customer-list-->
     
     </div>
    
    </div><!---row--->
   
   
   <div class="row">
     <div class="col-lg-6 col-md-6 col-sm-8 col-xs-12  pull-right">
	   
       <div class="pagination-wrp">
          <ul class="pagination pagination-lg">
		  <?php echo $links; ?>
          </ul>
       </div><!---pagination-wrp--->   
	 </div>
   
   </div><!---row--->  
          <div class="cl"></div>
          </div><!---innner-frm--->
       </div><!---customer-list-->
	 </div>
	</div>   
	</div>
</div>
	