<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

		 <div class="frm-heading"><h2>All Visit Cases</h2></div>
		 <table class="table table-bordered table-responsive">
             <thead>	
			  <tr>
				<!--<th>Customer Name</th>-->
				<th>Contact Type</th>
				<th>Agent Name</th>
				<th>Visit Date</th>
				<th style="width:25%">Visit Case Note</th>				
				<!--<th>How did you hear about us?</th>				
				<th>Result Reason</th>	-->
			  </tr>
           </thead>
			<tbody>
			<?php 
				
					
					foreach($visit_datas as $visit_data){		
			?>
				<tr><?php $rlreason = (array('rlreason')); ?>
				<!--<td><?php echo $visit_data['vcfname'] . ' ' . $visit_data['vclname']; ?></td>-->
					<td><?php echo $visit_data['contact_type']; ?></td>
					<td><?php echo $visit_data['user_name']; ?></td>
					<td><?php echo $visit_data['vcdate']; ?></td>
					<td><?php echo $visit_data['vcnote']; ?></td>
                                      <!--  <td><?php echo $visit_data['hear_about']; ?></td>
					<td><?php echo $visit_data['rlreason']; ?></td>-->
				</tr>
				<?php  
						
					}
				?> 
				
			</tbody>
         </table>
          <div class="cl"></div>
         