<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<div class="inner-wrp">
	<div  class="container-fluid">   
	<div class="row">
			<div class="col-md-12">
				<div id="flipMsg" >
				<?php if($this->session->flashdata('success')){ ?>
					<div class=" alert alert-success"><i class="fa fa-sucess"></i>
						<?php   echo   $this->session->flashdata('success'); ?>
					</div> 
				<?php } ?>	
				<?php if($this->session->flashdata('error')){ ?>
					<div class=" alert alert-danger"><i class="fa fa-warning"></i>
						<?php   echo   $this->session->flashdata('error'); ?>
					</div> 
				<?php } ?>	
				<?php if(isset($validation_error)){ ?>
					<div class=" alert alert-danger"><i class="fa fa-warning"></i>
						 <?php echo VALIDATION_ERROR_MESSAGE; ?>
					</div> 
				<?php } ?>	
				</div><!--flipMsg-->
			</div>
	 <div class="col-lg-12 col-md-12">
	  <div class="customer-list">
         <div class="frm-heading"><h2>Edit User</h2></div>
          <div class="inner-frm">
          <div class="row">
           <div class="col-lg-9 col-md-12">
               <div class="form-group">
			     <div class="row">
					<?php 
					foreach ($user_data as $user):
					$form_attributes = array('name' => 'edituser', 'id' => 'edituser');
					echo form_open('admin/update_user/'. $user['user_id'], $form_attributes);
					?>
				<input type="hidden" value="<?php echo $user['user_id']; ?>" name="user_id" id="user_id" />
				<input type="hidden" value="<?php echo $user['user_role']; ?>" name="user_role" id="user_role" />
				<input type="hidden" value="<?php echo $user['reset_token']; ?>" name="reset_token" id="reset_token" />
					
					<div class="col-md-6">
						<label class="col-sm-6 control-label">User Name : <span class="req">*</span></label>
						<div class="col-sm-6">
							<input type="text" class="form-control" value="<?php echo $user['user_name'];?>" name="user_name" id="user_name" placeholder="Username" />
							<?php echo form_error('user_name', '<div class="error">', '</div>'); ?>
							<div class="errorMessage" id="user_name_error"></div>
						</div>
					</div>
					<div class="col-md-6">
						<label class="col-sm-6 control-label" for="inputEmail3">Email : <span class="req">*</span></label>
						<div class="col-sm-6">
							<input type="email" name="email" placeholder="Email" class="form-control" id="email" value="<?php echo $user['email_id'];?>">
							<?php echo form_error('email', '<div class="error">', '</div>'); ?>
							<div class="errorMessage" id="email_error"></div>
						</div>
					</div>
					
					<div class="col-md-6">
						<label class="col-sm-6 control-label">First Name : <span class="req">*</span></label>
						<div class="col-sm-6">
							<input type="text" placeholder="First Name" class="form-control" value="<?php echo $user['first_name'];?>" name="first_name" maxlength="50" >
							<?php echo form_error('first_name', '<div class="error">', '</div>'); ?>
							<div class="errorMessage" id="first_name_error"></div>
						</div>
					</div>
				   
					<div class="col-md-6">
						<label class="col-sm-6 control-label" for="inputEmail3">Last Name : <span class="req">*</span></label>
						<div class="col-sm-6">
							<input type="text" placeholder="Last Name" value="<?php echo $user['last_name'];?>" name="last_name" class="form-control" maxlength="50">
							<?php echo form_error('last_name', '<div class="error">', '</div>'); ?>
							<div class="errorMessage" id="last_name_error"></div>
						</div>
					</div>
                  
					<div class="col-md-6">
						<label class="col-sm-6 control-label" for="inputEmail3">Phone # : <span class="req">*</span></label>
						<div class="col-sm-6">
							<input type="text" name="contact" onkeyup='validateInputField("contact", "numeric")' value="<?php echo $user['phone'];?>" placeholder="Phone" class="form-control">
							<?php echo form_error('contact', '<div class="error">', '</div>'); ?>
							<div class="errorMessage" id="contact_error"></div>
						</div>
					</div>
					<div class="col-md-6">
						<label class="col-sm-6 control-label" for="inputEmail3">Password : <span class="req">*</span></label>
						<div class="col-sm-6">
							<input type="password" class="form-control" check="password" value="" name="password" id="password" placeholder="Password" />
							<?php echo form_error('password', '<div class="error">', '</div>'); ?>
						<div class="errorMessage" id="password_error"></div>
						</div>
					</div>
					<div class="col-md-6">
						<label class="col-sm-6 control-label" for="inputEmail3">Confirm Password : <span class="req">*</span></label>
						<div class="col-sm-6">
							<input type="password" class="form-control" check="cpassword" value="" name="cpassword" id="cpassword" placeholder="Confirm Password" />
							<?php echo form_error('cpassword', '<div class="error">', '</div>'); ?>
							<div class="errorMessage" id="cpassword_error"></div>
						</div>
					</div>
					<div class="cl"></div>
					<div class="col-md-8">
						<div class="col-sm-8 req" >
							<?php echo MANDATORY_FIELDS_MESSAGE; ?>
						</div>
					</div>
					
				    <div class="col-md-6">
						<div class="col-sm-6">
							<div class="btn_wrp" >
								<input class="btn_greencl" type="submit" value="Save" />
								<a href="<?php echo base_url().'admin/listusers';?>" class="btn_creamcl" >Cancel</a>
								<div class="cl"></div>
							</div>
						</div>
					</div>
					
				   <?php echo form_close(); endforeach; ?>
				    
                   </div><!---row--->
                   </div><!---row--->
           </div>
          </div>
          <div class="cl"></div>
          </div><!---innner-frm--->
       </div><!---customer-list-->
	 </div>
	</div>   
	</div>
</div>