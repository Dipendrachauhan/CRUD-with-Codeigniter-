<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {
	 private $data = array();
    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     * 		http://example.com/index.php/welcome
     * 	- or -
     * 		http://example.com/index.php/welcome/index
     * 	- or -
     * Since this controller is set as the default controller in
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see http://codeigniter.com/user_guide/general/urls.html
     */
    public function __construct() {
        parent::__construct();
        $this->load->helper(array('form','url','email','sessionauth'));
        $this->load->library(array('form_validation','session','pagination','app/paginationlib'));
        $this->load->model(array('user_login_model','admin_model'));
		checkSessionsa();
		$this->data['user_id'] 			= $this->session->userdata('user_id');
		$this->data['user_role'] 		= $this->session->userdata('user_role');
		$this->data['user_name'] 		= $this->session->userdata('user_name');
		$this->data['email_id'] 		= $this->session->userdata('email_id');
		$this->data['phone'] 			= $this->session->userdata('phone');
    }
    public function index() {
        redirect('user_login/login', '');	
    }
    /*
     * 
     * Dashboard function
     * 
     */
	public function dashboard() 
	{	
		redirect('/admin/addcustomers');
		$data = $this->data;
        $data['title'] = 'Admin dashboard';
		$data['menu'] = $this->load->view('template/admin/menu', $data, TRUE);
        $this->load->view('template/admin/header', $data);
        $this->load->view('admin/dashboard');
        $this->load->view('template/admin/footer');
    }

// Add User
	public function addusers() {
		$data = $this->data;
		$data['title'] 			= 'Add Users';
		$this->form_validation->set_rules('user_name', 'User Name', 'trim|required|is_unique[user_login.user_name]');
		$this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');
        $this->form_validation->set_rules('first_name', 'First Name', 'trim|required|max_length[50]');
		$this->form_validation->set_rules('last_name', 'Last Name', 'trim|required|max_length[50]');
		$this->form_validation->set_rules('contact', 'Phone No.', 'trim|required|numeric');
		$this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[6]');
        $this->form_validation->set_rules('cpassword', 'Confirm Password', 'required|matches[password]');
		if($this->input->post())
		{
			if($this->form_validation->run() === FALSE) 
			{
				$data['title'] = 'Add User';
				$data['validation_error'] = true;
			}
			else 
			{
				if($this->admin_model->addUsers()){
				$this->session->set_flashdata('success', ADD_RECORD_MESSAGE);
				redirect('admin/listusers', '');
				}	
			}
		}
		$data['menu'] = $this->load->view('template/admin/menu', $data, TRUE);
		$this->load->view('template/admin/header', $data);
		$this->load->view('admin/addusers');
		$this->load->view('template/admin/footer');
    }
// List User	
	public function listusers(){
	    $data = $this->data;
		$data['title'] 			= 'List Users';
	    $pagingConfig   = $this->paginationlib->initPagination("/admin/listusers",$this->admin_model->get_count_clients()); 
		$page 			= ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
		$data['users'] = $this->admin_model->get_client_by_range($pagingConfig["per_page"], $page);
		$data["links"] =  $this->pagination->create_links();
		$data['menu'] = $this->load->view('template/admin/menu', $data, TRUE);
		$this->load->view('template/admin/header', $data);
		$this->load->view('admin/listusers', $data);
		$this->load->view('template/admin/footer');
	} 
	
//Edit user
	function edit_user($user_id = null) {
		
		$data = $this->data;
        $data['title'] 		= 'Edit User';
		 if($user_id)
		 { 
			$data['user_data'] = $this->admin_model->edit_user($user_id);
			$data['menu'] = $this->load->view('template/admin/menu', $data, TRUE);
			$this->load->view('template/admin/header', $data);
			$this->load->view('admin/edituser', $data);
			$this->load->view('template/admin/footer');
		 }
		 else
		 {
			 $this->session->set_flashdata('error', 'existing id does not match');
				redirect('admin/listusers', ''); 
		 }
	}
	function update_user($user_id) {
		
		$updatedata = $this->data;
		$updatedata['title'] 			= 'Update User';
		//$this->form_validation->set_rules('user_name', 'User Name', 'trim|required|is_unique[user_login.user_name]');
		//$this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');
        //$this->form_validation->set_rules('first_name', 'First Name', 'trim|required|max_length[50]');
		//$this->form_validation->set_rules('last_name', 'Last Name', 'trim|required|max_length[50]');
		//$this->form_validation->set_rules('contact', 'Phone No.', 'trim|required|numeric');
		//$this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[6]');
        //$this->form_validation->set_rules('cpassword', 'Confirm Password', 'trim|required|min_length[6]|matches[password]');
		if($this->input->post())
		{
			
			//if($this->form_validation->run() === FALSE) 
			//{
			//	print_r($this->input->post());die;
			///	$updatedata['title'] = 'Update User';
			//	$updatedata['validation_error'] = true;
			//}
			//else 
			//{
				if($this->admin_model->update_user($user_id)){
				$this->session->set_flashdata('success', UPDATE_RECORD_MESSAGE);
					redirect('admin/listusers', '');
					}			
//}
		}
	}
//Delete user
public function delete_user($user_id) {   
    $this->load->model("Admin_model");
    $this->Admin_model->did_delete_row($user_id);
	
    }
// -------------------------Customer section-----------------------
// Add Customer
	public function addcustomers() {
		$data = $this->data;
		$data['title'] 			= 'Add Customers';
		$this->form_validation->set_rules('first_name', 'First Name', 'trim|required');
		$this->form_validation->set_rules('last_name', 'Last Name', 'trim|required');
		// Add new customer 
		if($this->input->post('customer_id') == ""){
			if($this->input->post())
			{
				if($this->form_validation->run() === FALSE) 
				{
					$data['title'] = 'Add Customers';
					$data['validation_error'] = true;
				}
				else 
				{
				if($this->admin_model->addcustomers()){
					
				$this->session->set_flashdata('success', ADD_RECORD_MESSAGE);
					redirect('admin/addcustomers', '');
					}	
				}
			}	
     }else{
	   if($this->input->post())
			{
				if($this->form_validation->run() === FALSE) 
				{
					$data['title'] = 'Add Customers';
					$data['validation_error'] = true;
				}
				else 
				{
				if($this->admin_model->update_customer($this->input->post('customer_id'))){
					
				$this->session->set_flashdata('success', 'Customer updated successfully.');
					redirect('admin/addcustomers', '');
				}	
				}
			}	
	 }		
		$data['menu'] = $this->load->view('template/admin/menu', $data, TRUE);
		$this->load->view('template/admin/header', $data);
		$this->load->view('admin/addcustomers');
		$this->load->view('template/admin/footer');
    }
// List Customer
     public function listcustomers(){
	    $data = $this->data; 
	    $data['title'] = 'List Customers';
	    $pagingConfig   = $this->paginationlib->initPagination("/admin/listcustomers",$this->admin_model->get_count_customers()); 
		$page 			= ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
		$data['customers'] = $this->admin_model->get_customers_by_range($pagingConfig["per_page"], $page);
	    $data["links"] =  $this->pagination->create_links();
		$data['menu'] = $this->load->view('template/admin/menu', $data, TRUE);
		$this->load->view('template/admin/header', $data);
		$this->load->view('admin/listcustomers', $data);
		$this->load->view('template/admin/footer');
	} 
// Edit Customer

	public	function edit_customer($id = null) {
		$data = $this->data;
        $data['title'] 		= 'Edit Customer';
		 if($id)
		 { 
			$data['customer_data'] = $this->admin_model->edit_customer($id);
			$data['menu'] = $this->load->view('template/admin/menu', $data, TRUE);
			$this->load->view('template/admin/header', $data);
			$this->load->view('admin/editcustomer', $data);
			$this->load->view('template/admin/footer');
		 }
		 else
		 {
			 $this->session->set_flashdata('error', 'existing id does not match');
				redirect('admin/listcustomers', ''); 
		 }
	}	
	
	function update_customer($id) {
		$updatedata = $this->data;
		$updatedata['title'] 			= 'Update Customer';
		$this->form_validation->set_rules('first_name', 'First Name', 'trim|required');
		$this->form_validation->set_rules('last_name', 'Last Name', 'trim|required');
		if($this->input->post())
		{
			if($this->form_validation->run() === FALSE) 
			{
				$updatedata['title'] = 'Update Customers';
				$updatedata['validation_error'] = true;
			}
			else 
			{
			if($this->admin_model->update_customer($id)){
				
			$this->session->set_flashdata('success', ADD_RECORD_MESSAGE);
				redirect('admin/listcustomers', '');
			}	
			}
		}		
		$updatedata['menu'] = $this->load->view('template/admin/menu', $updatedata, TRUE);
		$this->load->view('template/admin/header', $updatedata);
		$this->load->view('admin/editcustomers');
		$this->load->view('template/admin/footer');

	}
// Delete Customer 
 public function deletecustomer($id) {   
		$this->load->model("Admin_model");
		$this->Admin_model->customer_delete_row($id);
		redirect($_SERVER['HTTP_REFERER']);
				
 }
 
 
// List Visit Cases  

public function listvisitcases(){
	    $data = $this->data; 
	    $data['title'] = 'List Cases';
	    $pagingConfig   = $this->paginationlib->initPagination("/admin/listvisitcases",
		$this->admin_model->get_count_visitcase()); 
		$page 			= ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
		$data['customers'] = $this->admin_model->get_visitcase_by_range($pagingConfig["per_page"], $page);
	    $data["links"] =  $this->pagination->create_links();
		$data['menu'] = $this->load->view('template/admin/menu', $data, TRUE);
		$this->load->view('template/admin/header', $data);
		$this->load->view('admin/listvisitcases', $data);
		$this->load->view('template/admin/footer');
	}  
 
// Search Customer 
 public function searchcustomer() {
	 
		$data = $this->data;
		$data['title'] 			= 'Search customer\'s visit case';
		$search = $this->input->get('search');
		
		if($search){
			
				$customer_data = $this->admin_model->search_customer($search);
				if($customer_data){
				$data['customer_data'] = $customer_data;
				if(count($customer_data) <=1){
				$data['visit_data'] = $this->admin_model->visit_data($customer_data[0]['id']);
				}
				$data['menu'] = $this->load->view('template/admin/menu', $data, TRUE);
				$this->load->view('template/admin/header', $data);
				$this->load->view('admin/serachcustomer',$data);
				$this->load->view('template/admin/footer');
                                }
                              else{
				
				$this->session->set_flashdata('No', 'Data Found');
				redirect($_SERVER['HTTP_REFERER']);
			            }		
			  }
			else
			{
				$this->session->set_flashdata('No', 'Data Found');
				redirect($_SERVER['HTTP_REFERER']);
				
			}
	}
	//individual visit case
	public function customer_visit_case($id){
	$data = $this->data;
    $data['title'] 			= 'Search customer\'s visit case';
	 if($id){
	           $customer_data = $this->admin_model->view_visit_case_individual($id);
				
				$data['customer_data'] = $customer_data;
				$data['visit_data'] = $this->admin_model->visit_data($customer_data['id']);
				$data['menu'] = $this->load->view('template/admin/menu', $data, TRUE);
				$this->load->view('template/admin/header', $data);
				$this->load->view('admin/individual-visit-case',$data);
				$this->load->view('template/admin/footer');	
		 }else{
			$this->session->set_flashdata('error', 'Error occurred');
			redirect('admin/listcustomers', '');
		}
	}
	public function ajexsearch(){
		
			
				if($this->input->post('name'))
					{
					
					$data['ajax_data'] = $this->admin_model->ajax_data($this->input->post('name'),$this->input->post('param'));
					$data['param'] = $this->input->post('param');
					$html = $this->load->view('admin/ajaxdata', $data, TRUE);
				     echo $html;
					
					}
	}
	
// Ajax for customer search box

		public function ajexsearchbox(){
					
				if($this->input->post('search'))
					{
					//print_r($this->input->post('search'));die;
					$data['ajax_data'] = $this->admin_model->ajax_databox($this->input->post('search'));
					
					$html = $this->load->view('admin/ajaxdatabox', $data, TRUE);
				     echo $html;
					}
	}
	
	
	
	
	public function complete_ajax_data(){
 echo json_encode($this->admin_model->ajax_data_complete($this->input->post('id')));
	}
	public function customer_visit_case_ajax(){
	$data = $this->data;
   
	 if($this->input->post('id')){
	          
				
				
				$visitcase = $this->admin_model->visit_data($this->input->post('id'));

				if(count($visitcase ) > 0){
				$data['visit_datas'] = $visitcase;
				 $this->load->view('admin/individual-visit-case-ajax',$data);
				}
				
		}
	}
	
	public function update_edit_customer($id){
		
		$updatedata = $this->data;
		$updatedata['title'] 			= 'Update Customer';
		$this->form_validation->set_rules('first_name', 'First Name', 'trim|required');
		$this->form_validation->set_rules('last_name', 'Last Name', 'trim|required');
			if($this->input->post())
				{
					
					if($this->form_validation->run() === FALSE) 
					{
						//print_r($this->input->post());die;
						$updatedata['title'] = 'Update Customers';
						$updatedata['validation_error'] = true;
					}
					else 
					{	
						if($this->admin_model->update_edit_customer($id)){
							
							$this->session->set_flashdata('success', UPDATE_RECORD_MESSAGE);
							redirect('admin/listcustomers', '');
						}	
					}
				}		
		$updatedata['menu'] = $this->load->view('template/admin/menu', $updatedata, TRUE);
		$this->load->view('template/admin/header', $updatedata);
		$this->load->view('admin/editcustomers');
		$this->load->view('template/admin/footer');		
	}

	
}