<?php
class User_login_model extends CI_Model {

	public function __construct(){
		$this->load->database();
	}
	
/*
*
** Forgot pass email check
*/

	
/*
* 
* User login function crm
* 
*/  
	public function login($login){
		$user_name = $login['username'];
		$password = md5($login['password']); 
		$this->db->select('*');
		$this->db->from('user_login');
		$this->db->where('user_name', $user_name);
		$this->db->where('password', $password);
		$this->db->where('status', 1);
		$this->db->limit(1);
		$query = $this->db->get();
		if ($query->num_rows() == 1)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
/*
* 
* User Role details by username function crm
* 
*/  
	public function userDetailsRole($username){
		$this->db->select('*');
		$this->db->from('user_login');
		$this->db->where('user_name', $username);
		$query = $this->db->get();
		return $query->row_array();  
	}
	

	

	
}