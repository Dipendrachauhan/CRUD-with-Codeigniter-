<?php defined('BASEPATH') OR exit('No direct script access allowed.');
/*
 * 
 *  Check session 
 * 
 * 
 */
if(!function_exists('checkSession'))
{
    function checkSession()
    { 
         $CI =& get_instance();
         if (!isset($CI->session->userdata['email']))
                {

                 redirect('admin/login','');
    
    }
}
           }
     
/*
 * 
 *  Change image and first name
 * 
 * 
 */
if(!function_exists('changeImageName'))
{
    function changeImageName()
    {
        $CI =& get_instance(); 
        if (isset($CI->session->userdata['user_id']))
        {
            $user_id=$CI->session->userdata['user_id'];
            $CI->load->library('encrypt');
            $CI->load->model('user_model');
            $arr=array('user_id'=>$user_id);
            $udata=$CI->user_model->commonFunction($arr);
            $upArray=array('image'=>$CI->encrypt->decode($udata['0']['image']),
                          'first_name'=>$udata['0']['first_name'].'  '.$CI->encrypt->decode($udata['0']['last_name'])    
                );
                return $upArray;;
        }
     }
}

/*
 * 
 *  Bredcrumbs 
 * 
 * 
 */
if(!function_exists('bredcrembs'))
{
  function bredcrembs()
    {
      $CI =& get_instance(); 
      $uriarray=array('controller'=> $CI->uri->segment('1'),
                'method'=> $CI->uri->segment('2')
              );
        return $uriarray;
    }
}