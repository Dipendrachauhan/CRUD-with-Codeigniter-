<div class="inner-wrp">
	<div  class="container-fluid">   
		<div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="customer-list">
					<img class="img-responsive" src="<?php echo base_url();?>assets/img/crm.png" alt="crm logo"/>
					<div class="inner-frm">
						<div class="row">
							<div class="col-lg-9 col-md-12">
								<div class="form-group">
									<div class="row">
										<div class="col-md-6">
											Dear <?php echo $email_data['first_name']; ?>,
											<br><br>
											You are registered successfully in CRM. Please go to this link for payment and continue your services in CRM.<br>
											<a href="<?php echo base_url(); ?>client_payment/payment_process/token/<?php echo $email_data['payment_link']; ?>">Go for Payment</a>
											<br><br>
											Your Login Credentials:<br>
											Username : <?php echo $email_data['user_name']; ?>
											<br>
											Password :  Go to link to set your password. <a href="<?php echo base_url(); ?>user_login/setpassword/<?php echo $email_data['pass_link']; ?>">Set your password</a>
											<br><br>
											Thanks,<br>
											CRM
										</div>
									</div>
									</div>
								</div><!---row--->
							</div>
						</div>
					</div><!---innner-frm--->
				</div><!---customer-list-->
			</div>
		</div>
	</div>
</div>