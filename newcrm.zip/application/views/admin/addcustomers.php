<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<!-- JavaScript to show google map -->
 
<div class="inner-wrp">
	<div  class="container-fluid">   
	<div class="row">
			<div class="col-md-12">
				<div id="flipMsg" >
				<?php if($this->session->flashdata('success')){ ?>
						<div class=" alert alert-success"><i class="fa fa-sucess"></i>
							<?php   echo   $this->session->flashdata('success'); ?>
						</div> 
				<?php } ?>	
				<?php   if($this->session->flashdata('error')){ ?>
					<div class=" alert alert-danger"><i class="fa fa-warning"></i>
						<?php   echo   $this->session->flashdata('error'); ?>
					</div> 
				<?php } ?>	
				</div><!--flipMsg-->
			</div>
	 <div class="col-lg-12 col-md-12">
	  <div class="customer-list">
           <script type="text/javascript">						
				$(function(){
					$(".search").keyup(function() 
					{ 
					var fullname = $(this).val();
					var dataString = 'search='+ fullname;
					if(fullname!='')
					{
					$.ajax({
						type: "POST",
						url: "<?php echo base_url(). '/admin/ajexsearchbox';?>",
						data: dataString,
						cache: false,
						success: function(html)
						{
						if(html== 'no'){
						$("#result1").html('<div style="padding:5px" align="left">No matching records.</div>').show();									
						}else{
						$("#result1").html(html).show();
						}									
						}
					});
					}
						return false;    
					});	
					
					$("#searchcustomer").on('click',".show", function(e){
					var customer_name = jQuery(this).children('span').html();
					$("#first_name").val(customer_name);
					
				    var id = jQuery(this).attr('id').split('_')[1];
					$("#customer_id").val(id);
					var data = 'id='+ id;
					// send ajax to get complete data from the table for the customer id
						$.ajax({
									type: "POST",
									url: "<?php echo base_url(). '/admin/complete_ajax_data';?>",
									data: data,
									cache: false,
									success: function(data)
										{
										
										 var json = $.parseJSON(data);
                                        var arr = json[0].rlreason.split(',');
										$('#rlreason').find('option').each(function() {
										 if(jQuery.inArray($(this).val(), arr) != -1) {
											  $(this).prop('selected', true);
											} 
										 });
										
											
										$("#first_name").val(json[0].fname); 
										$("#lname").val(json[0].lname); 
										$("#datepicker1").val(json[0].desire_date); 
										$("#living_status").val(json[0].living_status); 
										$("#datepicker").val(json[0].follow_up_date); 
										$("#hear_about").val(json[0].hear_about); 
										$("#phome").val(json[0].phome); 
										$("#mobile").val(json[0].mobile); 
										$("#pbusiness").val(json[0].pbusiness); 
										$("#fax").val(json[0].fax); 
										$("#street").val(json[0].street); 
										$("#city").val(json[0].city); 
										$("#state").val(json[0].state); 
										$("#zip").val(json[0].zip); 
										$("#country").val(json[0].country); 
										
										}
								});
								$.ajax({
									type: "POST",
									url: "<?php echo base_url(). '/admin/customer_visit_case_ajax';?>",
									data: data,
									cache: false,
									success: function(data)
										{
										$("#visitcase").html(data);
										}
										});
						
						});
	
					$("#searchcustomer").on('click',".show", function(e){
					var customer_name = jQuery(this).children('span').html();
					
					$("#search").val(customer_name);
					//var searchedid = jQuery(this).attr('id').split('_')[1];
					// var url = BASE_URL+'admin/addcustomers/'+'id/'+searchedid+'/serachedtext/'+customer_name;
					 
					// window.location.href = url; 
					$(document).on('click', function(e) { 
						var $clicked = $(e.target);
						if (! $clicked.hasClass("search")){
							$("#result1").fadeOut(); 
						}
					});
					});		
					});
					
		</script>


         <div class="frm-heading">
		 <div class="customer-head"><h2>Main Form</h2></div>
		 
			 <div class="form-group inp_search">
			 <form id="searchcustomer" role="form" action="<?php //echo base_url().'admin/searchcustomer';?>">			
					<input autocomplete="off" name="search" type="text" value="<?php if(isset($_GET['search'])){ echo $_GET['search'];} ?>" class="form-control search" placeholder="Search Customers" id="search">
					<button class="search_btn"><i class="fa fa-search"></i></button>
					<div id="result1"></div>
				  
				</form>
			</div>
			
		</div>
          <div class="inner-frm">
          <div class="row">
           <div class="col-sm-12 col-md-12">		   
               <div class="form-group">
					<?php 
					$form_attributes = array('name' => 'addcustomers', 'id' => 'addcustomers');
					echo form_open('admin/addcustomers', $form_attributes);
					?>
       			<div class="row">
					<div class="col-md-12">
						<script type="text/javascript">						
				$(function(){
					$(".fname").keyup(function() 
					{ 
						var firstname = $(this).val();
						 var element_id = ($(this).attr('id'));
						 if(element_id == 'first_name'){
							 var param = 'fname';
						 }else{
							 var param = 'lname';
						 }
						var dataString = 'name='+ firstname+'&param='+param;
						if(firstname!='')
						{
							$.ajax({
								type: "POST",
								url: "<?php echo base_url(). '/admin/ajexsearch';?>",
								data: dataString,
								cache: false,
								success: function(html)
									{
									if(html== 'no'){
									if(element_id == 'first_name'){
									  $("#result").html('<div class="" style="padding:6px" align="left">No matching records.</div>').show();
									}else{
									 $("#result2").html('<div class="" style="padding:6px" align="left">No matching records.</div>').show();	
									}
									$("#visitcase").html('');
									$("#customer_id").val('');
									//document.getElementById("addcustomers").reset();
                                       
										//$("#lname").val('');
										$("#datepicker1").val(Date(year, month, day)); 
										$("#living_status").val(Date(year, month, day)); 
										$("#rlreason").val(''); 
										$("#datepicker").val(''); 
										$("#hear_about").val(''); 
										$("#phome").val('');
										$("#mobile").val('');
										$("#pbusiness").val(''); 
										$("#fax").val('');
										$("#street").val('');
										$("#city").val('');
										$("#state").val('');
										$("#zip").val('');
										$("#country").val('');									
									}else{
									if(element_id == 'first_name'){	
									  $("#result").html(html).show();
									 }else{
									  $("#result2").html(html).show(); 
									 }
									}
									
									
									}
							});
						}
						return false;    
					});		  
						
					$("#addcustomers").on('click',".show", function(e){
					var customer_name = jQuery(this).children('span').html();
					$("#first_name").val(customer_name);
					
				    var id = jQuery(this).attr('id').split('_')[1];
					$("#customer_id").val(id);
					var data = 'id='+ id;
					// send ajax to get complete data from the table for the customer id
						$.ajax({
									type: "POST",
									url: "<?php echo base_url(). '/admin/complete_ajax_data';?>",
									data: data,
									cache: false,
									success: function(data)
										{
										
										 var json = $.parseJSON(data);
                                        var arr = json[0].rlreason.split(',');
										$('#rlreason').find('option').each(function() {
										 if(jQuery.inArray($(this).val(), arr) != -1) {
											  $(this).prop('selected', true);
											} 
										 });
										
											
										$("#first_name").val(json[0].fname); 
										$("#lname").val(json[0].lname); 
										$("#datepicker1").val(json[0].desire_date); 
										$("#living_status").val(json[0].living_status); 
										$("#datepicker").val(json[0].follow_up_date); 
										$("#hear_about").val(json[0].hear_about); 
										$("#phome").val(json[0].phome); 
										$("#mobile").val(json[0].mobile); 
										$("#pbusiness").val(json[0].pbusiness); 
										$("#fax").val(json[0].fax); 
										$("#street").val(json[0].street); 
										$("#city").val(json[0].city); 
										$("#state").val(json[0].state); 
										$("#zip").val(json[0].zip); 
										$("#country").val(json[0].country); 
										
										}
								});
								$.ajax({
									type: "POST",
									url: "<?php echo base_url(). '/admin/customer_visit_case_ajax';?>",
									data: data,
									cache: false,
									success: function(data)
										{
										$("#visitcase").html(data);
										}
										});
						
						});
						
					$(document).on('click', function(e) { 
						var $clicked = $(e.target);
						if (! $clicked.hasClass(".fname")){
							$("#result").fadeOut(); 
							$("#result2").fadeOut(); 
						}
					});
					 
					
					});
								
					</script>						
					<div class="col-md-2">
						<label class="control-label">First Name : <span class="req">*</span></label>
							<input id="first_name" type="text" placeholder="First Name" class="form-control fname"  autocomplete="off" value="<?php echo set_value('first_name');?>" name="first_name" maxlength="50" onkeyup="javascript:capitalize(this.id, this.value);">
							<?php echo form_error('first_name', '<div class="error">', '</div>'); ?>
							<div class="errorMessage" id="first_name_error"></div>
							<div id="result"></div>
					</div>
				   <input id="customer_id" type="hidden"  value="" name="customer_id">
					<div class="col-md-2">
						<label class="control-label">Last Name : <span class="req">*</span></label>
							<input type="text" autocomplete="off" id="lname" placeholder="Last Name" value="<?php echo set_value('last_name');?>" name="last_name" class="form-control fname" maxlength="50">
							<?php echo form_error('last_name', '<div class="error">', '</div>'); ?>
							<div class="errorMessage" id="last_name_error"></div>
							<div id="result2"></div>
					</div>
					
					<div class="col-md-2">
						<label class="control-label">Desired Move-In Date:</label>
							<input id="datepicker1" readonly type="text" value="<?php echo date('Y-m-d');?>" name="desire_date" class="form-control calender-img" maxlength="50"> 
	 				</div>
					
					<div class="col-md-2">
						<label class="control-label">Current Living Status:</label>
						<select id="living_status" name="living_status">
						<option value="">Select Status</option>
						<option value="Renting" <?php if(array('living_status') == 'Renting'){ ?>selected<?php } ?>>Renting</option>
						<option value="firstime-renter" <?php if(array('living_status') == 'firstime-renter'){ ?>selected<?php } ?>>First Time Renter</option>
						<option value="living-with-parents" <?php if(array('living_status') == 'living-with-parents'){ ?>selected<?php } ?>>Living With Parents</option>
						<option value="home-owner" <?php if(array('living_status') == 'home-owner'){ ?>selected<?php } ?>>Home Owner</option>
						</select>
					</div>
						
					<div class="col-md-2">
					<script type="text/javascript">
						//$(function () {
						//	$('#rlreason').multiselect({
								//includeSelectAllOption: true
							//});
							
						//});
					</script>	

						<?php $rlreason = (array('rlreason')); ?>
					
						<label class="control-label">Result Reason:</label><br/>
						<select id="rlreason" name="rlreason[]" multiple>
						<option value="leased" <?php if(in_array('leased',$rlreason)){ ?>selected<?php } ?>>Leased</option>
						<option value="unqualified" <?php if(in_array('unqualified',$rlreason)){ ?>selected<?php } ?>>Unqualified</option>
						<option value="leasing" <?php if(in_array('leasing',$rlreason)){ ?>selected<?php } ?>>High Prob of Leasing</option>
						<option value="competition" <?php if(in_array('competition',$rlreason)){ ?>selected<?php } ?>>Lost 2 Competition</option>
						<option value="expensive" <?php if(in_array('expensive',$rlreason)){ ?>selected<?php } ?>>.. too Expensive</option>
						<option value="location" <?php if(in_array('location',$rlreason)){ ?>selected<?php } ?>>..Location</option>
						</select>
					</div>				
					<div class="col-md-2">
						<label class="control-label">Scheduled Follow-Up Date:</label>
						<input id="datepicker" readonly type="text" name="follow_up_date" value="<?php echo date('Y-m-d');?>" class="form-control calender-img">						
					</div>
					
				</div>
			</div>
			<div class="row">
				<div class="col-sm-12">
					<div class="col-md-2">
						<label class="control-label">How did you hear about us?</label>
						<select id="hear_about" name="hear_about">
						<option value="">Select</option>
						<option value="craigslist" <?php if(array('living_status') == 'Craigslist'){ ?>selected<?php } ?>>Craigslist</option>
						<option value="drive-by" <?php if(array('living_status') == 'drive-by'){ ?>selected<?php } ?>>Drive By</option>
						<option value="apartmens.com" <?php if(array('living_status') == 'apartmens.com'){ ?>selected<?php } ?>>Apartmens.com</option>
						<option value="apartment-finder.com" <?php if(array('living_status') == 'apartment-finder.com'){ ?>selected<?php } ?>>Apartment Finder.com</option>
						<option value="apartment-guide" <?php if(array('living_status') == 'apartment-guide'){ ?>selected<?php } ?>>Apartment Guide</option>
						<option value="freind" <?php if(array('living_status') == 'freind'){ ?>selected<?php } ?>>Freind</option>
						<option value="other" <?php if(array('living_status') == 'other'){ ?>selected<?php } ?>>Other</option>
						</select>
					</div>
					
				</div>
			</div>
			<div class="row">
					<div class="col-sm-12 col-md-12"><h4 style="color:#A6CE39;font-weight:bold">Contact Details</h4></div>
			</div>	
			<div class="row">
				<div class="col-md-12">
					<div class="col-md-2">
						<label class="control-label">Home (Phone No.):</label>
							<input type="text" id="phome" name="phome" value="<?php echo set_value('phome');?>" placeholder="Home Phone No." class="form-control" onkeydown="javascript:backspacerDOWN(this,event);" onkeyup="javascript:backspacerUP(this,event);">
							<?php echo form_error('phome', '<div class="error">', '</div>'); ?>
							<div class="errorMessage" id="contact_error"></div>
					</div>
					<div class="col-md-2">
						<label class="control-label">Mobile No.:</label>
							<input type="text" name="mobile" id="mobile" value="<?php echo set_value('mobile');?>" placeholder="Mobile No." class="form-control" onkeydown="javascript:backspacerDOWN(this,event);" onkeyup="javascript:backspacerUP(this,event);">
							<?php echo form_error('mobile', '<div class="error">', '</div>'); ?>
							<div class="errorMessage" id="contact_error"></div>
					</div>
					<div class="col-md-2">
						<label class="control-label">Business (Phone No.):</label>
							<input type="text" name="pbusiness" id="pbusiness" value="<?php echo set_value('pbusiness');?>" placeholder="Business Phone No." class="form-control" onkeydown="javascript:backspacerDOWN(this,event);" onkeyup="javascript:backspacerUP(this,event);">
							<?php echo form_error('pbusiness', '<div class="error">', '</div>'); ?>
							<div class="errorMessage" id="contact_error"></div>
					</div>
					
					<div class="col-md-2">
						<label class="control-label">Fax No.:</label>
							<input type="text" name="fax" id="fax" value="<?php echo set_value('fax');?>" placeholder="Fax No." class="form-control" onkeydown="javascript:backspacerDOWN(this,event);" onkeyup="javascript:backspacerUP(this,event);">
							<?php echo form_error('fax', '<div class="error">', '</div>'); ?>
							<div class="errorMessage" id="contact_error"></div>
					</div>
				</div>
			</div>

			<div class="row">
					<div class="col-sm-12 col-md-12"><h4 style="color:#A6CE39;font-weight:bold">Address</h4></div>	
			</div>	
			<div class="row">
				<div class="col-md-12">
					<div class="col-md-2">
						<label class="control-label">Street :</label>
							<input type="text" placeholder="Street" id="street" value="<?php echo set_value('street');?>" name="street" class="form-control" maxlength="50">
					</div>
					<div class="col-md-2">
						<label class="control-label">City :</label>
							<input type="text" placeholder="City" id="city" value="<?php echo set_value('city');?>" name="city" class="form-control" maxlength="50">
					</div>
					<div class="col-md-2">
						<label class="control-label">State :</label>
							<input type="text" placeholder="State" id="state"  value="<?php echo set_value('state');?>" name="state" class="form-control" maxlength="50">
					</div>
					<div class="col-md-2">
						<label class="control-label">Zip Code:</label>
							<input type="number" id="zip" name="zcode" onkeyup='validateInputField("zcode", "numeric")' value="<?php echo set_value('zcode');?>" placeholder="Zip Code" class="form-control">
							<?php echo form_error('zcode', '<div class="error">', '</div>'); ?>
							<div class="errorMessage" id="contact_error"></div>
					</div>
			
					<div class="col-md-2">
						<label class="control-label">Country :</label>
							<input type="text" placeholder="Country" id="country" value="<?php echo set_value('country');?>" name="country" class="form-control" maxlength="50">
					</div>
				</div>
		 </div>
		<div class="row">
					<div class="col-sm-12 col-md-12"><h4 style="color:#A6CE39;font-weight:bold">Add New Visit Case</h4></div>
		</div>
		<div class="row">
				<div class="col-md-12">				
					<div class="col-md-2">
					<label class="control-label">Contact Type:</label><br/>
					<select class="for-ui" id="ctype" name="contact_type">
					<option value="">Select Type</option>
					<option value="Visit">Visit</option>
					<option value="E-mail">E-mail</option>
					<option value="Phone Call">Phone Call</option>
					<option value="Fax">Fax</option>
					</select>
					</div>
												
					<div class="col-md-2">
						<label class="control-label">Visit Date:</label>
							<input readonly type="text" placeholder="Visit Date" value="<?php echo date('Y-m-d');?>" name="vcdate" class="form-control vcdate" maxlength="50">
					</div>
					<div class="col-md-2">
						<label class="control-label">Added By:</label>
							<input readonly type="text" name="contact" value="<?php echo $this->session->userdata('user_name');?>" placeholder="Agent Name" class="form-control user_name">
					</div>
				
					<div class="col-md-3">
						<label class="control-label">Visit Case Note:</label>
							<textarea type="text" placeholder="Vise Note" name="vcnote" class="form-control" ><?php echo set_value('vcnote');?></textarea>
					</div>
					<div class="col-md-3">
							<label class="control-label"></label>
							<div class="btn_wrp">
								<div class="col-md-6"><input class="btn_greencl" type="submit" value="Save" /></div>
								<div class="col-md-6"><a href="<?php echo base_url().'admin/listcustomers';?>" class="btn_creamcl" >Cancel</a></div>
								<div class="cl"></div>
							</div>
					</div>
				</div>
		</div>
				   <?php
                   echo form_close();
				   ?>
				   <div id="visitcase"></div>
				    </div>
                   </div><!---row--->
           </div>
          </div>
          <div class="cl"></div>
          </div><!---innner-frm--->
       </div><!---customer-list-->
	 </div>
	</div>

  
   
</div>
<script language="javascript">

<!-- This script is based on the javascript code of Roman Feldblum (web.developer@programmer.net) -->
<!-- Original script : http://javascript.internet.com/forms/format-phone-number.html -->
<!-- Original script is revised by Eralper Yilmaz (http://www.eralper.com) -->
<!-- Revised script : http://www.kodyaz.com -->

var zChar = new Array(' ', '(', ')', '-', '.');
var maxphonelength = 14;
var phonevalue1;
var phonevalue2;
var cursorposition;

function ParseForNumber1(object){
phonevalue1 = ParseChar(object.value, zChar);
}
function ParseForNumber2(object){
phonevalue2 = ParseChar(object.value, zChar);
}

function backspacerUP(object,e) { 
if(e){ 
e = e 
} else {
e = window.event 
} 
if(e.which){ 
var keycode = e.which 
} else {
var keycode = e.keyCode 
}

ParseForNumber1(object)

if(keycode >= 48){
ValidatePhone(object)
}
}

function backspacerDOWN(object,e) { 
if(e){ 
e = e 
} else {
e = window.event 
} 
if(e.which){ 
var keycode = e.which 
} else {
var keycode = e.keyCode 
}
ParseForNumber2(object)
} 

function GetCursorPosition(){

var t1 = phonevalue1;
var t2 = phonevalue2;
var bool = false
for (i=0; i<t1.length; i++)
{
if (t1.substring(i,1) != t2.substring(i,1)) {
if(!bool) {
cursorposition=i
bool=true
}
}
}
}

function ValidatePhone(object){

var p = phonevalue1

p = p.replace(/[^\d]*/gi,"")

if (p.length < 4) {
object.value=p
} else if(p.length==4){
pp=p;
d4=p.indexOf('(')
d5=p.indexOf(')')
if(d4==-1){
pp="("+pp;
}
if(d5==-1){
pp=pp+")";
}
object.value = pp;
} else if(p.length>4 && p.length < 7){
p ="(" + p; 
l40=p.length;
p40=p.substring(0,4);
p40=p40+")"

p41=p.substring(4,l40);
pp=p40+p41;

object.value = pp; 

} else if(p.length >= 7){
p ="(" + p; 
l40=p.length;
p40=p.substring(0,4);
p40=p40+") "

p41=p.substring(4,l40);
pp=p40+p41;

l40 = pp.length;
p40 = pp.substring(0,9);
p40 = p40 + "-"

p41 = pp.substring(9,l40);
ppp = p40 + p41;

object.value = ppp.substring(0, maxphonelength);
}

GetCursorPosition()

if(cursorposition >= 0){
if (cursorposition == 0) {
cursorposition = 2
} else if (cursorposition <= 2) {
cursorposition = cursorposition + 1
} else if (cursorposition <= 5) {
cursorposition = cursorposition + 2
} else if (cursorposition == 6) {
cursorposition = cursorposition + 2
} else if (cursorposition == 7) {
cursorposition = cursorposition + 4
e1=object.value.indexOf(')')
e2=object.value.indexOf('-')
if (e1>-1 && e2>-1){
if (e2-e1 == 4) {
cursorposition = cursorposition - 1
}
}
} else if (cursorposition < 11) {
cursorposition = cursorposition + 4
} else if (cursorposition == 11) {
cursorposition = cursorposition + 1
} else if (cursorposition >= 12) {
cursorposition = cursorposition
}

var txtRange = object.createTextRange();
txtRange.moveStart( "character", cursorposition);
txtRange.moveEnd( "character", cursorposition - object.value.length);
txtRange.select();
}

}

function ParseChar(sStr, sChar)
{
if (sChar.length == null) 
{
zChar = new Array(sChar);
}
else zChar = sChar;

for (i=0; i<zChar.length; i++)
{
sNewStr = "";

var iStart = 0;
var iEnd = sStr.indexOf(sChar[i]);

while (iEnd != -1)
{
sNewStr += sStr.substring(iStart, iEnd);
iStart = iEnd + 1;
iEnd = sStr.indexOf(sChar[i], iStart);
}
sNewStr += sStr.substring(sStr.lastIndexOf(sChar[i]) + 1, sStr.length);

sStr = sNewStr;
}

return sNewStr;
}
</script>