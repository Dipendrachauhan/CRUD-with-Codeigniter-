-- phpMyAdmin SQL Dump
-- version 4.4.12
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 06, 2016 at 05:43 PM
-- Server version: 5.6.25
-- PHP Version: 5.5.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `getdel`
--

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE IF NOT EXISTS `customers` (
  `id` mediumint(9) NOT NULL,
  `fname` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `desire_date` date NOT NULL,
  `living_status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rlreason` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `follow_up_date` date NOT NULL,
  `phome` int(11) NOT NULL,
  `mobile` int(11) NOT NULL,
  `pbusiness` int(11) NOT NULL,
  `fax` int(11) NOT NULL,
  `street` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `zip` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `fname`, `lname`, `desire_date`, `living_status`, `rlreason`, `follow_up_date`, `phome`, `mobile`, `pbusiness`, `fax`, `street`, `city`, `state`, `zip`, `country`, `user_name`) VALUES
(22, 'Dipendra', 'Singh', '2016-02-09', 'renting', 'leased', '2016-02-10', 2147483647, 2147483647, 2147483647, 2147483647, 'B-792, New Ashok Nagar', 'New Delhi', 'Charch Wali Gali', '110096', 'India', 'admin@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `user_login`
--

CREATE TABLE IF NOT EXISTS `user_login` (
  `user_id` int(11) NOT NULL,
  `user_role` int(1) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email_id` varchar(255) NOT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT '0',
  `reset_token` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_login`
--

INSERT INTO `user_login` (`user_id`, `user_role`, `user_name`, `first_name`, `last_name`, `password`, `email_id`, `phone`, `status`, `reset_token`) VALUES
(1, 1, 'admin@gmail.com', '', '0', 'e10adc3949ba59abbe56e057f20f883e', 'nishant.nigam@otssolutions.com', '9999171787', 1, ''),
(19, 2, 'ashit@gmail.com', 'Ashit', 'kumar', 'e10adc3949ba59abbe56e057f20f883e', 'ashitkumar8910@gmail.com', '9891548486', 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_role`
--

CREATE TABLE IF NOT EXISTS `user_role` (
  `id` int(11) NOT NULL,
  `role` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_role`
--

INSERT INTO `user_role` (`id`, `role`) VALUES
(1, 'Admin'),
(2, 'Subadmin');

-- --------------------------------------------------------

--
-- Table structure for table `visite_case`
--

CREATE TABLE IF NOT EXISTS `visite_case` (
  `id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `vcname` varchar(255) NOT NULL,
  `contact_type` varchar(255) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `vcdate` varchar(255) NOT NULL,
  `vcnote` varchar(1000) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `visite_case`
--

INSERT INTO `visite_case` (`id`, `customer_id`, `vcname`, `contact_type`, `user_name`, `vcdate`, `vcnote`) VALUES
(19, 22, 'Dipendra', 'Phone Call', 'admin@gmail.com', '2016-03-06', 'afsgggdfgd gfd gdfgdg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_login`
--
ALTER TABLE `user_login`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `user_role`
--
ALTER TABLE `user_role`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `visite_case`
--
ALTER TABLE `visite_case`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` mediumint(9) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT for table `user_login`
--
ALTER TABLE `user_login`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT for table `user_role`
--
ALTER TABLE `user_role`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `visite_case`
--
ALTER TABLE `visite_case`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=20;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
