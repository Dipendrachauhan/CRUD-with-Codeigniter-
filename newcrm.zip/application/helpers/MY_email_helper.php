<?php defined('BASEPATH') OR exit('No direct script access allowed.');

    if(!function_exists('adminMailSend'))
    {
    function adminMailSend($to,$message=null,$subject=null)
    {   
    $CI =& get_instance();
    $CI->load->library('PHPMailer');
    $CI->load->library('SMTP');     
    $CI->phpmailer->IsSMTP();                                      // set mailer to use SMTP
    $CI->Host = "103.47.150.61";  // specify main and backup server
    $CI->phpmailer->SMTPAuth = true;     // turn on SMTP authentication
    $CI->phpmailer->SMTPSecure = 'ssl';    
    $CI->phpmailer->Username = "projtest@otssolutions.com";  // SMTP username
    $CI->phpmailer->Password = "ots@4737"; // SMTP password
    $CI->phpmailer->From = "projtest@otssolutions.com";
    $CI->phpmailer->FromName = "System Admin";
    $CI->phpmailer->AddAddress($to, "");
    $CI->phpmailer->WordWrap = 50;                                 // set word wrap to 50 characters

    //$CI->IsHTML(true);    
    if(!empty($subject))
    {
    $CI->phpmailer->Subject = $subject;
    }
    else{
        $CI->phpmailer->Subject = "Test";
    }
    if(!empty($message))
    {
    $CI->phpmailer->Body    = $message;
    }
    else{
        $CI->phpmailer->Body    = "This is a test email";
    }
    $CI->phpmailer->AltBody = "This is the body in plain text for non-HTML mail clients";
     //print_r($CI->phpmailer); die;
    if(!$CI->phpmailer->Send())
    {
       return "Mailer Error: " . $CI->phpmailer->ErrorInfo;
       exit;
    }

    return "Message has been sent";



     }
    }
