<?php
class User_model extends CI_Model {

        public function __construct()
        {
            $this->load->database();
        }
        
/*
* 
* Admin login function
* 
*/  
        
      public function login($login)
      {
            $email=$login['email'];
            $password=md5($login['password']); 
            $this->db->select('*');
            $this->db->from('user');
            $this->db->where('email', $email);
            $this->db->where('password', $password);
            $this->db->where('status', '1');
            $this->db->limit(1);
            $query = $this->db->get();
            if ($query->num_rows() == 1)
            {
               
                return true;
            }
            else
            {
                return false;
            }
         }
/*
* 
* Admin details by email function
* 
*/  
        public function userDetails($email)
         {
             $this->db->select('*');
            $this->db->from('user');
            $this->db->where('email', $email);
            $query = $this->db->get();
            return $query->result();  
         }
/*
* 
* Admin detail by token function
* 
*/  
    
         public function userDetailsByToken($token)
         {
             $this->db->select('*');
            $this->db->from('user');
            $this->db->where('reset_token', $token);
            $query = $this->db->get();
            return $query->result(); 
         }

/*
* 
* Admin email verify function
* 
*/  
            public function emailVerified($email)
         {
             $this->db->from('user');
             $this->db->where('email',$email);
             $this->db->limit(1);
             $query = $this->db->get();
            if ($query->num_rows() == 1)
            {
                return true;
            }
            else
            {
                return false;
            }
         }
         
/*
* 
* Reset token function
* 
*/  
    
         public function resetToken($email,$reset_token)
         {
             $this->db->set('reset_token',$reset_token);
             $this->db->where('email', $email);
             if($this->db->update('user'))
             {
                 return true;
             }
         }
/*
* 
*Admin update password function
* 
*/  
           
         public function updatePassword($id,$uparr)
         {
             $this->db->set('date_modified',$uparr['date_modified']);
             $this->db->where('user_login_id', $id);
             if($this->db->update('user'))
             {
                 return true;
             }
           }
/*
* 
* Common function for get details
* 
*/  
             
           public function commonFunction($data)
           {
               $str='';
              
               if(!empty($data) &&  $data!='')
               {    
                    $str.='select * from `user` join user_login on `user`.user_login_id = user_login.user_id  where 1=1 ';
                   if(!empty($data['user_id']))
                   {
                      $str.=' AND `user`.user_login_id="'.$data['user_id'].'"';   
                   }
                   if(!empty($data['first_name']))
                   {
                      $str.=' AND `user`.first_name="'.$data['first_name'].'"';   
                   }
                   if(!empty($data['email']))
                   {
                      $str.=' AND user_login.email="'.$data['email'].'"';   
                   }
                   if(!empty($data['contact']))
                   {
                      $str.=' AND `user`.contact="'.$data['contact'].'"';   
                   }
                      $query=$this->db->query($str);
                      return  $query->result_array();
               }
               else
               {
                     $str.='select * from user join user_login on user.user_id == user_login.user_id';
                    $query=$this->db->query($str);
                    return  $query->result_array();
               }
           }
/*
* 
* Admin update profile function
* 
*/  
    
           public function updateProfile($id, $inArr)
           {
               
                   $this->db->where('user_id', $id);
                   if( $this->db->update('user', $inArr))
                   {
                       return true;
                   }
               
                
           }
           
/*
* 
* Admin role get  function
* 
*/  
    public function getRole($id)
    {
     $sql='SELECT t1.role_name FROM roles as t1 join user_role as t2 on t1.role_id=t2.role_id
           where t2.id="'.$id.'"';
     $query=$this->db->query($sql);
     return  $query->result_array();
    }
/*
* 
* Admin permission module for sidebar function
* 
*/  
    
public function getModules($id)
{
     $sql='SELECT t1.* FROM permissions as t1 join perm_role as t2 on t1.perm_id=t2.perm_id
           join user_role as t3 on t2.role_id=t3.role_id
           where t3.user_id="'.$id.'" ORDER BY `sort_order` ASC';
   $query=$this->db->query($sql);
   return  $query->result_array();

}
/*
* 
* Admin add user function
* 
*/  
    
public function addAdmin($inArr)
{
  if( $this->db->insert('user',$inArr))
  {
      return $this->db->insert_id();
  }
}

/*
* 
* List Admin  function
* 
*/  
    
public function listAdmin(){
    $this->db->select('*');
    $this->db->from('user')
            ->join('user_login','user.user_login_id=user_login.user_id');
    $this->db->where('user_login.user_type =','3');
    $status = $this->input->get('status');
    if($status!=null){
      $this->db->where('user.status =',$status);  
    }
    $query=$this->db->get();
    return $query->result();
}
/*
* 
* Edit Admin data function
* 
*/  
public function editAdmin($id,$upArr)
{

    $this->db->where('user_login_id',$id);
  if( $this->db->update('user',$upArr))
  {
      return true;
  }
}

/*
* 
* Delete Admin data function
* 
*/  
public function deleteAdmin($id)
{
   $this->db->where('user_id', $id);
  if($this->db->delete('user'))
  {
      return true;
  }
 }
 
/*
* 
* Change admin status data function
* 
*/  
 public function changeStatusAdmin($id)
 {
     
     $this->db->select('status');
     $this->db->from('user');
     $this->db->where('user_login_id',$id);
     $query=$this->db->get();
     $statusdata= $query->result();
     $status=$statusdata[0]->status;
     $str='';
     if($status=='1')
     {
         $str='2';
     }
     if($status=='2')
     {
          $str='1';

     }
     $this->db->set('status',$str);
     $this->db->where('user_login_id',$id);
     if($this->db->update('user'))
     {
         return true;
     }

 }
 
 
/*
* 
* Get all user name function
* 
*/  
 
 public function getAllUserName()
 {
     $this->db->select('user_id');
     $this->db->select('first_name');
     $this->db->select('email');
     $this->db->from('user');
     $this->db->where('user_id !=','1');
     $query=$this->db->get();
     return $query->result();
 }

 
/*
* 
* Total revenue  function
* 
*/   
public function totalRevenue()
{
$sql1='select sum(order_amount) as total from  application_fee_order_payment ';
$query1=$this->db->query($sql1);
$appdata=  $query1->result_array();
$application_fee=  $appdata[0]['total'];
$sql2='select sum(amount) as total from  subscription_payment ';
$query2=$this->db->query($sql2);
$subdata=  $query2->result_array();
$subscription_fee=  $subdata[0]['total'];
$sql3='select sum(amount) as total from   rent_payment ';
$query3=$this->db->query($sql3);
$rentdata=  $query3->result_array();
$rentn_fee=  $rentdata[0]['total'];
return    $total=$application_fee+$subscription_fee+$rentn_fee;
}


 
/*
* 
* Get monthly revenue for dashboard function
* 
*/  


public function getMonthlyRevenue()
{
    $year=date('Y');
    $rent_payment=array();
    $subscription_payment=array();
    $application_fee_order_payment=array();
    $montharr=array('January','February','March','April','May','June','July','August','September','October','November','December');
    for($i=0;$i<12;$i++)
    {
    $sql='select sum(amount) as total from rent_payment where MONTHNAME(added_on) = "'.$montharr[$i].'"  AND  YEAR(added_on)="'.$year.'" ';
    $query=$this->db->query($sql);
    $rent_payment_month=  $query->result_array();
    if(empty($rent_payment_month[0]['total']))
    {
    $rent_payment[]=  '0'.',';  
    }
    else
    {
      $rent_payment[]=  $rent_payment_month[0]['total'].',';
    }
    }
    for($i=0;$i<12;$i++)
    {
    $sql='select sum(amount) as total from subscription_payment where MONTHNAME(added_on) = "'.$montharr[$i].'"  AND  YEAR(added_on)="'.$year.'" ';
    $query=$this->db->query($sql);
    $application_fee_order_payment_month=  $query->result_array();
    if(empty($application_fee_order_payment_month[0]['total']))
    {
    $subscription_payment[]=  '0'.',';  
    }
    else
    {
      $subscription_payment[]=  $application_fee_order_payment_month[0]['total'].',';
    }
    }

    for($i=0;$i<12;$i++)
    {
    $sql='select sum(order_amount) as total from application_fee_order_payment where MONTHNAME(added_on) = "'.$montharr[$i].'"  AND  YEAR(added_on)="'.$year.'" ';
    $query=$this->db->query($sql);
    $application_fee_order_payment_month=  $query->result_array();
    if(empty($application_fee_order_payment_month[0]['total']))
    {
    $application_fee_order_payment[]=  '0'.',';  
    }
    else
    {
      $application_fee_order_payment[]=  $application_fee_order_payment_month[0]['total'].',';
    }
    }
    $total='';
    for($i=0;$i<12;$i++)
    {
    $total.=$rent_payment[$i]+$subscription_payment[$i]+$application_fee_order_payment[$i].',';
    }
    $total=  rtrim($total,',');

    return $total;

}

/*
* 
* Get user data  function
* 
*/  
        
        
public function getUserData()
{
    $this->db->select('user_id');
    $this->db->select('first_name');
    $this->db->from('user');
    $query=$this->db->get();
    return   $query->result();
  }

/*
* 
* User reset password
* 
*/  
  
	public function  resetuserpassword($id,$password)
	{
		 $this->db->set('password',$password);
		$this->db->where('user_id', $id);
		if($this->db->update('user'))
		{
			return true;
		}
	}

	 public function email_exists($email){
	   
	   $sql = "SELECT first_name, email_id FROM user_login WHERE email_id='{$email}' LIMIT 1";
	  // print_r($sql);die;
	   $result = $this->db->query($sql);
	  // echo '<pre>';
	  // print_r($result);die;
	   $row = $result->row();
	 //echo '<pre>';
	   //print_r( $row);
	   //echo $result->num_rows;
	  // die;
	   return (count($row)>0) ? true : false;
	   
    }

	public function verify_reset_password_code($email, $code){
		
		$sql = "SELECT first_name, email_id FROM user_login WHERE email_id = '{$email}' LIMIT 1";
		$result = $this->db->query($sql);
		$row = $result->row();
		if($result->num_rows() === 1){
			return ($code == md5($this->config->item('salt'). $row->first_name)) ? true:false;
		}
		else {
			return false;	
		}	
	}
	
	public function update_password(){
		
		$email = $this->input->post($email);
		$password = sha1($this->config->item('salt') . $this->input->post('password'));
		$sql = "UPDATE user_login SET password = '{$password}' WHERE email = '{$email}' LIMIT 1";
		$this->db->query($sql);
		if($this->db->affected_rows() === 1) {
			
			return true;
			}
			else {
				
				return false;	
			}
	}
              
}