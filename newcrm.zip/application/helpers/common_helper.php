<?php defined('BASEPATH') OR exit('No direct script access allowed.');
function getCurrentDate(){ 
    return date('Y-m-d H:i:s',time());
}
