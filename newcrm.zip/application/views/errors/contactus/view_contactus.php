<?php
defined('BASEPATH') OR exit('No direct script access allowed');

?>
<section class="content">
          <div class="row">
            <div class="col-xs-12">
             <div class="box">
                <div class="box-header">
                  <h3 class="box-title">View Contact Us</h3>
                </div><!-- /.box-header -->
                <div class="box-body">
                  <table id="example1" class="table table-bordered table-striped">
                    <thead>
                      <tr>
                         <th>S.N.</th>  
                        <th>Username</th>
                        <th>Email</th>
                      </tr>
                    </thead>
                    <tbody>
                        <?php
                     if(!empty($singlecontactus))
                     {
                      ?>
                      <tr>
                        <td><?php echo '1';?></td>  
                        <td><?php  echo ucfirst($singlecontactus[0]->username);?></td>
                        <td><?php echo $singlecontactus[0]->email;?></td>
                        </tr>
                        
                     <?php }?>
                     </tbody>
                    <tfoot>
                      <tr>
                        <th>S.N.</th>  
                        <th>Username</th>
                        <th>Email</th>
                      </tr>
                    </tfoot>
                  </table>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        </section><!-- /.content -->
</div>