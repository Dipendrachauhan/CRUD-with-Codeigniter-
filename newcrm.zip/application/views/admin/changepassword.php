<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<script>
//var arrIdForm=["password","cpassword"];
</script>

<div class="inner-wrp">
	<div  class="container-fluid">   
		<div class="row">
			<div class="col-md-12">
				<div id="flipMsg" >
				<?php if($this->session->flashdata('success')){ ?>
						<div class=" alert alert-success"><i class="fa fa-sucess"></i>
							<?php   echo   $this->session->flashdata('success'); ?>
						</div> 
				<?php } ?>	
				<?php   if($this->session->flashdata('error')){ ?>
					<div class=" alert alert-danger"><i class="fa fa-warning"></i>
						<?php   echo   $this->session->flashdata('error'); ?>
					</div> 
				<?php } ?>	
				</div><!--flipMsg-->
			</div>
	 <div class="col-lg-12 col-md-12">
	  <div class="customer-list">
         <div class="frm-heading"><h2>Change Password</h2></div>
          <div class="inner-frm">
          <div class="row">
           <div class="col-lg-9 col-md-12">
               <div class="form-group">
			     <div class="row">
					<?php 
					 echo form_open_multipart('admin/changepassword');
					?>
					<div class="col-md-6">
						<label class="col-sm-6 control-label" for="inputEmail3">Old Password : <span class="req">*</span></label>
						<div class="col-sm-6">
							<input type="password" class="form-control" check="oldpassword" value="" name="oldpassword" id="oldpassword" placeholder="Old Password" />
							<?php echo form_error('oldpassword', '<div class="error">', '</div>'); ?>
							<div class="errorMessage" id="oldpassword_error"></div>
						</div>
					</div>
					<div class="cl"></div>
					<div class="col-md-6">
						<label class="col-sm-6 control-label" for="inputEmail3">Password : <span class="req">*</span></label>
						<div class="col-sm-6">
							<input type="password" class="form-control" check="password" value="" name="password" id="password" placeholder="Password" />
							<?php echo form_error('password', '<div class="error">', '</div>'); ?>
						<div class="errorMessage" id="password_error"></div>
						</div>
					</div>
					<div class="cl"></div>
					<div class="col-md-6">
						<label class="col-sm-6 control-label" for="inputEmail3">Confirm Password : <span class="req">*</span></label>
						<div class="col-sm-6">
							<input type="password" class="form-control" check="cpassword" value="" name="cpassword" id="cpassword" placeholder="Confirm Password" />
							<?php echo form_error('cpassword', '<div class="error">', '</div>'); ?>
							<div class="errorMessage" id="cpassword_error"></div>
						</div>
					</div>
					
					<div class="cl"></div>
					<div class="col-md-8">
						<div class="col-sm-8 req" >
							<?php echo MANDATORY_FIELDS_MESSAGE; ?>
						</div>
					</div>
				    <div class="col-md-8">
						<div class="col-sm-6">
						<div class="btn_wrp" >
							<input class="btn_greencl" type="submit" value="Change Password" />
							<a href="<?php echo base_url().'admin/dashboard';?>" class="btn_creamcl" >Cancel</a>
							<div class="cl"></div>
						</div>
						</div>
					</div>
				
				   <?php
                   echo form_close();
				   ?>
				    </div>
                   </div><!---row--->
           </div>
          </div>
          <div class="cl"></div>
          </div><!---innner-frm--->
       </div><!---customer-list-->
	 </div>
	</div>
	</div>
</div>