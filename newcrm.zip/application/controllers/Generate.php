<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Generate extends CI_Controller{
		 private $data = array();

	function Generate()
    {
        parent::__construct();
        $this->load->database();
		$this->load->helper(array('form','url','email','sessionauth'));
        $this->load->library(array('form_validation','session','pagination','app/paginationlib'));
        $this->load->model(array('user_login_model','admin_model'));
		checkSessionsa();
		$this->data['user_id'] 			= $this->session->userdata('user_id');
		$this->data['user_role'] 		= $this->session->userdata('user_role');
		$this->data['user_name'] 		= $this->session->userdata('user_name');
		$this->data['email_id'] 		= $this->session->userdata('email_id');
		$this->data['phone'] 			= $this->session->userdata('phone');
    }

        function create_csv(){

				$query = $this->admin_model->create_csv();
				$download = 'VisitCases_'.date('dMy').'.csv';
				//query_to_csv($quer,TRUE,'Products_'.date('dMy').'.csv');
				header("Content-Type: text/csv");
				header("Content-Disposition: attachment; filename=$download ");
				# Disable caching - HTTP 1.1
				header("Cache-Control: no-cache, no-store, must-revalidate");
				# Disable caching - HTTP 1.0
				header("Pragma: no-cache");
				# Disable caching - Proxies
				header("Expires: 0");
				$headers = true;
			    $array = array();
        
        if ($headers)
        {
		$cols = array('Id', 'Customer Id', 'First Name', 'Last Name', 'Contact Type', 'Agent Name', 'Visit Date', 'Case Note','How did you hear about us?', 'Result Reason');
            $line = array();
            foreach ($cols as $name)
            {
                 $line[] = $name;
            }
			
            $array[] = $line;
        }
        
        foreach ($query->result_array() as $row)
        {
            $line = array();
            foreach ($row as $item)
            {
                $line[] = $item;
            }
            $array[] = $line;
        }
		
        # Start the ouput
        $output = fopen("php://output", "w");
		
         # Then loop through the rows
        foreach ($array as $row) {
            # Add the rows to the body
            fputcsv($output, $row); // here you can change delimiter/enclosure
        }
        # Close the stream off
        fclose($output);
            
        }
		
}