<?php
if(!empty($followup_data)){?>
<div class="inner-wrp">
	<div  class="container-fluid">   
		<div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="customer-list">
					<div class="inner-frm">
						<div class="row">
							<div class="col-lg-9 col-md-12">
								<div class="form-group">
									<div class="row">
										<div class="col-md-6">
											Dear Admin,
											<br><br>
											<p>You have to follow following customers</p>
											<table border=1>
											<tr>
											<th>First Name</th>
											<th>Last Name</th>
											<th>Mobile No.</th>
											</tr>
											<?php foreach($followup_data as $followups){ ?>
											<tr>
											<td><?php echo $followups['fname'] ?></td>
											<td><?php echo $followups['lname'] ?></td>
											<td><?php echo $followups['mobile'] ?></td>
											</tr>
											<?php } ?>
											
											</table>
											<?php //print_r($followup_data); ?>
											<br><br>
											Thanks,<br>
											CRM
										</div>
									</div>
									</div>
								</div><!---row--->
							</div>
						</div>
					</div><!---innner-frm--->
				</div><!---customer-list-->
			</div>
		</div>
	</div>
</div>
<?php }  else {?>
<div class="inner-wrp">
	<div  class="container-fluid">   
		<div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="customer-list">
					<div class="inner-frm">
						<div class="row">
							<div class="col-lg-9 col-md-12">
								<div class="form-group">
									<div class="row">
										<div class="col-md-6">
											Dear Admin,
											<br><br>
											Today You have no customers to Followup
											<br><br>
											Thanks,<br>
											CRM
										</div>
									</div>
									</div>
								</div><!---row--->
							</div>
						</div>
					</div><!---innner-frm--->
				</div><!---customer-list-->
			</div>
		</div>
	</div>
</div>
<?php } ?>