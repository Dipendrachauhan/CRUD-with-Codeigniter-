<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class User_login extends CI_Controller {

    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     * 		http://example.com/index.php/welcome
     * 	- or -
     * 		http://example.com/index.php/welcome/index
     * 	- or -
     * Since this controller is set as the default controller in
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see http://codeigniter.com/user_guide/general/urls.html
     */
    public function __construct() {
		
        parent::__construct();
        $this->load->helper(array('form','url','email'));
        $this->load->library(array('form_validation','session'));
        $this->load->model(array('user_login_model', 'user_model'));
		
    }

    public function index() {
		
        redirect('user/login', '');
		
    }

    /*
     * 
     * Login function  
     * 
     */

    public function login() 
	{ 
	
        $this->form_validation->set_rules('username', 'User Name', 'trim|required');
        $this->form_validation->set_rules('password', 'Password', 'required');
		
        $login = array(
            'username' => $this->input->post('username'),
            'password' => $this->input->post('password')
        );
			
		$username = $this->input->post('username');
		if($this->form_validation->run() == FALSE) 
		{
			$data['title'] = 'User login';
			$this->load->view('user_login/signin', $data);
		}
		else 
		{
			if($_SERVER["REQUEST_METHOD"] == "POST")
			{
				if($this->user_login_model->login($login) == TRUE) 
				{
				
					$userdatas 	= $this->user_login_model->userDetailsRole($username);
					 
					
					$this->session->set_userdata($userdatas, $value = NULL);
					 
						redirect('admin/addcustomers');
					
					
				} 
				else 
				{
					$this->session->set_flashdata('error', 'Invalid login credentials');
					$data['title'] = 'User login';
					$this->load->view('user_login/signin', $data);
				}
			}
		}
    }

	 /*
     * 
     * Logout function
     * 
     */

    public function logout() {
		$this->session->sess_destroy();
		redirect('user/login');
    } 
	
	public function update_password(){
		
		if(!isset($_POST['email'], $_POST['email_hash']) || $_POST['email_hash'] !==sha1($_POST['email'] . $_POST['email_code'])){
			
			die('Error updating Your password');
	
		}
		$this->load->library('form_validation');
		$this->form_validation->set_rules('email_hash', 'Email Hash', 'trim|required');
		$this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email|xss_clean');
		$this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[6]|matches[password_conf]|xss_clean');
		$this->form_validation->set_rules('password_conf', 'New Password', 'trim|required|min_length[6]|xss_clean');
		
		if($this->form_validation->run() == FALSE){
			$this->load->view('user_login/view_update_password');
		}
		else {
			
		$result = $this->User_model->update_password();
		if($result){
			$this->load->view('user_login/view_update_password_success');
			
		}
		else{
			
			$this->load->view('user_login/view_update_password', array('error' => 'Problem Update Your Password Please contact Adminstrator'));	
		}
			
		}
	}	
		
		public function reset_password_form($email, $email_code){
			
			if(isset($email, $email_code)){
				
				$email = trim($email);
				$email_hash = sha1($email . $email_code);
				$varified = $this->User_model->verify_reset_password_code($email, $email_code);
				
				if($varified){
					
					$this->load->view('user_login/view_update_password', array('eamil_hash' => $email_hash, 'email_code' => $email_code, 'email' => $email));
				}
				else{
					
					$this->load->view('user_login/view_reset_password', array('error' => 'There is problem with your link'));
				}
				
			}
			
			
		}
		
	public function reset_password(){
		$data['title'] = 'Reset Password';
	if(isset($_POST['email']) && !empty($_POST['email'])){
		
		$this->load->library('form_validation');
		
		 $this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');
		 
			if($this->form_validation->run() == FALSE){
					print_r($_POST['email']);die;
				  $this->load->view('user_login/signin', array('error' => 'Please Enter a valid Email Address'));
				} else	{
					
					$email = trim($this->input->post('email'));
					$result = $this->user_model->email_exists($email);
			
					if($result){
						$this->send_reset_password_email($email, $result);
						$this->load->view('user_login/view_reset_password_sent', array('email' => $email), $data);
						} else {
							
						$this->load->view('user_login/view_reset_password', array('error' => 'Please Enter Registered Email Address'), $data);
						}
					}	
		
		} else {
		$this->load->view('user_login/view_reset_password', $data);
		}
	}
		
	public function send_reset_password_email($email, $first_name){
		
		$this->load->library('email');
		$email_code = md5($this->config->item('salt') . $first_name);
		
		$this->email->set_mailtype('html');
		$this->email->from($this->config->item('bot_email'), 'my.com');
		$this->email->to($email);
		$this->email->subject('Please reset your Password');
		
		$message = '<html><body>';
		
		$message = '<p>Dear' . $first_name . ',</p>';
		
		$message = '<p>Please click on this link <a href="' . base_url() . 'user_login/reset_password_form' . $email . '/' . $email_code . '">click Here</a></p>';
		
		$message = '</body></html>';
		$this->email->message($message);
		$this->email->send();
		
	}	
	
	
	
}