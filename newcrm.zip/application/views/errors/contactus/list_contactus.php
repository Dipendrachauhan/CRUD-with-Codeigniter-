<?php
defined('BASEPATH') OR exit('No direct script access allowed');

?>


 <section class="content">
          <div class="row">
            <div class="col-xs-12">
             

              <div class="box">
                <div class="box-header">
                  <h3 class="box-title">Contact us listing</h3>
                </div><!-- /.box-header -->
                <div class="box-body">
                  <table id="example1" class="table table-bordered table-striped">
                    <thead>
                      <tr>
                         <th>S.N.</th>  
                        <th>Username</th>
                        <th>Email</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $i=1;
                        if(!empty($contactus) && $contactus!='')
                        { 
                           foreach($contactus as $value)
                        {
                        
                        ?>
                      <tr>
                        <td><?php echo $i;?></td>  
                        <td><?php echo ucfirst($value->username);?></td>
                        <td><?php echo $value->email;?></td>
                        <td>
                            <div class="ac_action">
                            <div style="height: 38px;">
                             <a class="" style=" margin-left: 26px;" title="View Contact Us" href="<?php echo base_url().'contactus/view_contact_us/'.$value->id;?>" ><i class="fa fa-eye"></i> View</a>                           
                           </div> 
                          </div>
                          </td>
                           
                      </tr>
                        <?php  $i++;}}?>
                      
                    </tbody>
                    <tfoot>
                      <tr>
                        <th>S.N.</th>  
                        <th>Username</th>
                        <th>Email</th>
                        <th>Action</th>
                      </tr>
                    </tfoot>
                  </table>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        </section><!-- /.content -->
</div>