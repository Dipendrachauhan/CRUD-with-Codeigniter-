<?php

 if(count($ajax_data) > 0){
foreach($ajax_data as $ajax) 
							{ 
			echo '<div class="show"  id="my_'.$ajax['id'].'"><span class="full_name" >'.$ajax['fname'] . ' ' . $ajax['lname'].'</span></div>'; 	
							}
						}else{
							//echo '<div class="" align="left">No matching records.</div>';
                            echo "no";							
						}?>