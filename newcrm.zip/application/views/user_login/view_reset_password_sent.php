<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html>
  <head>
    <title>CRM | <?php echo $title;?></title>
    <meta charset="utf-8">
	<meta name="format-detection" content="telephone=no">
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />

	<!---css----->
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/style-sheet.css"/>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/font/styles-font-calibri.css"/>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/bootstrap-3.3.6-dist/css/bootstrap.css"/>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/font-awesome-4.5.0/css/font-awesome.css"/>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/styles-nav.css"/>

	<!---css end----->

	<!--script--->
	<script type="text/javascript" src="<?php echo base_url();?>assets/js/jquery-2.2.0.min.js"></script>
	<script type="text/javascript" src="<?php echo base_url();?>assets/js/script.js"></script>
	<script type="text/javascript" src="<?php echo base_url();?>assets/bootstrap-3.3.6-dist/js/bootstrap.js"></script>

</head>
  <body>
    <div class="login-page-wrp">
		<div class="row">	
			<div class="login-frm">
			<p>A link is sent to your registred emailid <?php echo $email;?></p>
			</div>
	    </div>
    </div>
  </body>
</html>