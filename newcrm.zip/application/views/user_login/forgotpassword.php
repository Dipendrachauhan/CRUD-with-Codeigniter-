<!DOCTYPE html>
<html>
  <head>
    <title>CRM | <?php echo $title;?></title>
    <meta charset="utf-8">
	<meta name="format-detection" content="telephone=no">
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />

	
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/style-sheet.css"/>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/font/styles-font-calibri.css"/>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/bootstrap-3.3.6-dist/css/bootstrap.css"/>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/font-awesome-4.5.0/css/font-awesome.css"/>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/styles-nav.css"/>

	
	<script type="text/javascript" src="<?php echo base_url();?>assets/js/jquery-2.2.0.min.js"></script>
	<script type="text/javascript" src="<?php echo base_url();?>assets/js/script.js"></script>
	<script type="text/javascript" src="<?php echo base_url();?>assets/bootstrap-3.3.6-dist/js/bootstrap.js"></script>
	<style>
     body{ background: rgba(0, 0, 0, 0) url("<?php echo base_url();?>assets/img/login-bg.jpg") no-repeat scroll center center / 100% auto;}
	 .error{background-color: red;margin-top: 5px; color: #fff; }  
     .success{background-color: green;margin-top: 5px;color: #fff;}
     #flipMsg{  margin-left: 0px;padding-top: 2px;margin-bottom: 12px;text-align: center;}    
    </style>
	<script>
	$(document).ready(function(){
		setTimeout(function(){$("#flipMsg").slideUp('fast'); }, 10000);
	});
  </script>
</head>
  <body>
    <div class="login-page-wrp">
		<div class="row">	
			<div class="login-frm">
        <?php if(isset($token)){?>
			  <p class="login-box-msg">Update Password</p>
			  <div id="flipMsg">
					<?php if(isset($password_update)){?>
						  <div   class=" alert alert-success messageBoxHeight">
						  <?php   echo $password_update; ?>
						  </div>
					<?php } if(isset($error)){?>
						<div class="alert alert-danger messageBoxHeight">
						   <?php echo $error; ?>
						</div>
					<?php } if(isset($email_success)){ ?>
					 <div class="alert alert-success ">
					  <?php   echo $email_success; ?>
					</div>
					<?php }if(isset($link_expired)) { ?>
					 <div class="alert alert-danger">
					   <?php echo $link_expired; ?>
					 </div>
					<?php }?>        
			  </div>
		    <?php echo form_open('user_login/forgotpassword/'.$token);?>
				  <div class="form-group">
				   <label for="password">Password</label>
					<input type="password" name="password" id="password"  class="form-control" placeholder="Password">
					<?php echo form_error('password', '<div  class="alert alert-danger messageBoxHeight">', '</div>'); ?>
					<span class="glyphicon glyphicon-envelope form-control-feedback"></span>
				  </div>
				 <div class="form-group has-feedback">
				    <label for="cpassword">Password</label>
					<input type="password" name="cpassword" id="cpassword"  class="form-control" placeholder="Confirm Password">
					<?php echo form_error('cpassword', '<div  class="alert alert-danger messageBoxHeight">', '</div>'); ?>
					<span class="glyphicon glyphicon-envelope form-control-feedback"></span>
				 </div>
				  <button type="submit" class="btn btn-info btn-block login">Submit</button>
		    <?php echo form_close();?>
				   <a href="<?php echo base_url().'user_login/login';?>">Cancel</a><br>
				   
    <?php } else { ?>
		<p class="login-box-msg">Forgot Password</p>
			<div id="flipMsg">
				<?php if($this->session->flashdata('email_error')){ ?>
				 <div  class="alert alert-danger messageBoxHeight">
					<?php echo $this->session->flashdata('email_error'); ?>
				 </div>
				<?php } if($this->session->flashdata('email_success')){ ?>
				<div class="alert alert-success messageBoxHeight">
				<?php   echo $this->session->flashdata('email_success'); ?>
				</div>
				<?php   }  ?>
			</div>
		   <?php echo form_open('user_login/forgotpassword');?>
		   
			  <div class="form-group">
			  <label for="email">Email</label>
				<input type="text" name="email" id="email"  class="form-control" placeholder="Email">
				 <?php echo form_error('email', '<div  class="alert alert-danger messageBoxHeight">', '</div>'); ?>
			  <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
			  </div>
			 
			  <button type="submit" class="btn btn-info btn-block login">Submit</button>
		 <?php echo form_close();?>
	 <a href="<?php echo base_url().'user_login/login';?>">Cancel</a><br>
	<?php } ?>
          </div>
       </div>
	</div>
	<footer class="bg_footer">
	   <div class="container-fluid">
	   <div class="col-lg-12">
		 <p class="text-center">Copyright © 2016 All Rights Reserved.<br/></p>
	   </div>
	   </div>
	</footer>
  </body>
</html>
