<div class="navigation-menu">
   <div class="container-fluid">
    <div class="row">
     <div class="col-lg-12">
      <div id='cssmenu'> 
		  <ul class="listhover">
		  <?php 
		   $CI =& get_instance();
		   $controller = $CI->router->fetch_class(); 
		   $action = $CI->router->fetch_method();
		  ?>
		  <?php if($user_role == 1) { ?>
				<li><a href="<?php echo base_url().'admin/listcustomers';?>"><span>Customers</span></a>
					<ul>
						 <li><a href='<?php echo base_url().'admin/addcustomers';?>'><span>Main Form</span></a></li>
						 <li><a href='<?php echo base_url().'admin/listcustomers';?>'><span>List Customers</span></a></li>
						 <li><a href='<?php echo base_url().'admin/listvisitcases';?>'><span>List Visit Cases</span></a></li>
					</ul>
				</li>
				<li><a href="<?php echo base_url().'admin/listusers';?>"><span>Users</span></a>
					<ul>
						 <li><a href='<?php echo base_url().'admin/addusers';?>'><span>Add User</span></a></li>
						 <li><a href='<?php echo base_url().'admin/listusers';?>'><span>List Users</span></a></li>
				  </ul>
				 </li>
		  <?php }else{ ?>
			
					 <li><a href='<?php echo base_url().'admin/addcustomers';?>'><span>Main Form</span></a></li>
					 <li><a href='<?php echo base_url().'admin/listcustomers';?>'><span>List Customers</span></a></li>
					 <li><a href='<?php echo base_url().'admin/listvisitcases';?>'><span>List Visit Cases</span></a></li>
			
		  <?php } ?>
		 </ul>
      </div>
     </div>
   </div>
   </div>
  </div>
       
	 