<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Permission_check{
	public function check_privilege(){
		$controllersArr =array(
					'admin' =>array(1,2)
		);
		$CI =& get_instance();
		$controller = $CI->router->fetch_class(); 
		if(array_key_exists($controller,$controllersArr)){
			$userRole = $CI->session->userdata('user_role');		
			if(!in_array($userRole,$controllersArr[$controller])){
				
				$CI->session->sess_destroy();
				
				redirect('user/login?permission=false');
			} 
		}
    }
}

?>