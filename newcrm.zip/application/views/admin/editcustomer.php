<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

<div class="inner-wrp">
	<div  class="container-fluid">   
	<div class="row">
			<div class="col-md-12">
				<div id="flipMsg" >
				<?php if($this->session->flashdata('success')){ ?>
					<div class=" alert alert-success"><i class="fa fa-sucess"></i>
						<?php   echo   $this->session->flashdata('success'); ?>
					</div> 
				<?php } ?>	
				<?php if($this->session->flashdata('error')){ ?>
					<div class=" alert alert-danger"><i class="fa fa-warning"></i>
						<?php   echo   $this->session->flashdata('error'); ?>
					</div> 
				<?php } ?>	
				<?php if(isset($validation_error)){ ?>
					<div class=" alert alert-danger"><i class="fa fa-warning"></i>
						 <?php echo VALIDATION_ERROR_MESSAGE; ?>
					</div> 
				<?php } ?>	
				</div><!--flipMsg-->
			</div>
	 <div class="col-lg-12 col-md-12">
	  <div class="customer-list">
         <div class="frm-heading"><h2>Edit User</h2></div>
          <div class="inner-frm">
          <div class="row">
               <div class="form-group">
					<?php 
					foreach ($customer_data as $customer):
					$form_attributes = array('name' => 'editcustomer', 'id' => 'editcustomer');
					echo form_open('admin/update_edit_customer/' . $customer['id'], $form_attributes);
					?>
				
					<div class="col-md-2">
						<input type="hidden" class="form-control" value="<?php echo $customer['id'];?>" name="id">
						<label class="control-label">First Name : <span class="req">*</span></label>
							<input id="first_name" type="text" placeholder="First Name" class="form-control fname"  autocomplete="off" value="<?php echo $customer['fname'];?>" name="first_name" maxlength="50" onkeyup="javascript:capitalize(this.id, this.value);">
							<?php echo form_error('first_name', '<div class="error">', '</div>'); ?>
							<div class="errorMessage" id="first_name_error"></div>
							<div id="result"></div>
					</div>

					<div class="col-md-2">
						<label class="control-label">Last Name : <span class="req">*</span></label>
							<input type="text" id="lname" placeholder="Last Name" value="<?php echo $customer['lname'];?>" name="last_name" class="form-control" maxlength="50">
							<?php echo form_error('last_name', '<div class="error">', '</div>'); ?>
							<div class="errorMessage" id="last_name_error"></div>
					</div>
					
					<div class="col-md-2">
						<label class="control-label">Desired Move-In Date:</label>
							<input id="datepicker1" readonly type="text" value="<?php echo $customer['desire_date'];?>" name="desire_date" class="form-control calender-img" maxlength="50"> 
	 				</div>
					
					<div class="col-md-2">
						<label class="control-label">Current Living Status:</label>
						<select id="living_status" name="living_status">
						<option value="">Select Status</option>
						<option value="Renting" <?php if($customer['living_status'] == 'Renting'){ ?>selected<?php } ?>>Renting</option>
						<option value="firstime-renter" <?php if($customer['living_status'] == 'firstime-renter'){ ?>selected<?php } ?>>First Time Renter</option>
						<option value="living-with-parents" <?php if($customer['living_status'] == 'living-with-parents'){ ?>selected<?php } ?>>Living With Parents</option>
						<option value="home-owner" <?php if($customer['living_status'] == 'home-owner'){ ?>selected<?php } ?>>Home Owner</option>
						</select>
					</div>
					
					<div class="col-md-2">
						<?php $rlreason = explode(',',$customer['rlreason']); ?>
						<label class="control-label">Result Reason:</label><br/>
						<select id="rlreason" name="rlreason[]" multiple>
						<option value="leased" <?php if(in_array('leased',$rlreason)){ ?>selected<?php } ?>>Leased</option>
						<option value="unqualified" <?php if(in_array('unqualified',$rlreason)){ ?>selected<?php } ?>>Unqualified</option>
						<option value="leasing" <?php if(in_array('leasing',$rlreason)){ ?>selected<?php } ?>>High Prob of Leasing</option>
						<option value="competition" <?php if(in_array('competition',$rlreason)){ ?>selected<?php } ?>>Lost 2 Competition</option>
						<option value="expensive" <?php if(in_array('expensive',$rlreason)){ ?>selected<?php } ?>>.. too Expensive</option>
						<option value="location" <?php if(in_array('location',$rlreason)){ ?>selected<?php } ?>>..Location</option>
						</select>
					</div>				
					<div class="col-md-2">
						<label class="control-label">Scheduled Follow-Up Date:</label>
						<input id="datepicker" readonly type="text" name="follow_up_date" value="<?php echo $customer['follow_up_date'];?>" class="form-control calender-img">						
					</div>
					</div>
			</div>
			<div class="row">
				<div class="col-md-12">	
					<div class="col-md-2">
						<label class="control-label">How did you hear about us?</label>
						<select id="hear_about" name="hear_about">
						<option value="">Select</option>
						<option value="craigslist" <?php if($customer['hear_about'] == 'craigslist'){ ?>selected<?php } ?>>Craigslist</option>
						<option value="drive-by" <?php if($customer['hear_about'] == 'drive-by'){ ?>selected<?php } ?>>Drive By</option>
						<option value="apartmens.com" <?php if($customer['hear_about'] == 'apartmens.com'){ ?>selected<?php } ?>>Apartmens.com</option>
						<option value="apartment-finder.com" <?php if($customer['hear_about'] == 'apartment-finder.com'){ ?>selected<?php } ?>>Apartment Finder.com</option>
						<option value="apartment-guide" <?php if($customer['hear_about'] == 'apartment-guide'){ ?>selected<?php } ?>>Apartment Guide</option>
						<option value="freind" <?php if($customer['hear_about'] == 'freind'){ ?>selected<?php } ?>>Freind</option>
						<option value="other" <?php if($customer['hear_about'] == 'other'){ ?>selected<?php } ?>>Other</option>
						</select>
					</div>
				</div>
			</div>
			<div class="row">
					<div class="col-sm-12 col-md-12"><h4 style="color:#A6CE39;font-weight:bold">Contact Details</h4></div>
			</div>	
			<div class="row">
				<div class="col-md-12">
					<div class="col-md-2">
						<label class="control-label">Home (Phone No.):</label>
							<input type="text" id="phome" name="phome" value="<?php echo $customer['phome'];?>" placeholder="Home Phone No." class="form-control" onkeydown="javascript:backspacerDOWN(this,event);" onkeyup="javascript:backspacerUP(this,event);">
							<?php echo form_error('phome', '<div class="error">', '</div>'); ?>
							<div class="errorMessage" id="contact_error"></div>
					</div>
					<div class="col-md-2">
						<label class="control-label">Mobile No.:</label>
							<input type="text" name="mobile" id="mobile" value="<?php echo $customer['mobile'];?>" placeholder="Mobile No." class="form-control" onkeydown="javascript:backspacerDOWN(this,event);" onkeyup="javascript:backspacerUP(this,event);">
							<?php echo form_error('mobile', '<div class="error">', '</div>'); ?>
							<div class="errorMessage" id="contact_error"></div>
					</div>
					<div class="col-md-2">
						<label class="control-label">Business (Phone No.):</label>
							<input type="text" name="pbusiness" id="pbusiness" value="<?php echo $customer['pbusiness'];?>" placeholder="Business Phone No." class="form-control" onkeydown="javascript:backspacerDOWN(this,event);" onkeyup="javascript:backspacerUP(this,event);">
							<?php echo form_error('pbusiness', '<div class="error">', '</div>'); ?>
							<div class="errorMessage" id="contact_error"></div>
					</div>
					
					<div class="col-md-2">
						<label class="control-label">Fax No.:</label>
							<input type="text" name="fax" id="id" value="<?php echo $customer['fax'];?>" placeholder="Fax No." class="form-control" onkeydown="javascript:backspacerDOWN(this,event);" onkeyup="javascript:backspacerUP(this,event);">
							<?php echo form_error('fax', '<div class="error">', '</div>'); ?>
							<div class="errorMessage" id="contact_error"></div>
					</div>
				</div>
			</div>

			<div class="row">
					<div class="col-sm-12 col-md-12"><h4 style="color:#A6CE39;font-weight:bold">Address</h4></div>	
			</div>	
			<div class="row">
				<div class="col-md-12">
					<div class="col-md-2">
						<label class="control-label">Street :</label>
							<input type="text" placeholder="Street" id="street" value="<?php echo $customer['street'];?>" name="street" class="form-control" maxlength="50">
					</div>
					<div class="col-md-2">
						<label class="control-label">City :</label>
							<input type="text" placeholder="City" id="city" value="<?php echo $customer['city'];?>" name="city" class="form-control" maxlength="50">
					</div>
					<div class="col-md-2">
						<label class="control-label">State :</label>
							<input type="text" placeholder="State" id="state"  value="<?php echo $customer['state'];?>" name="state" class="form-control" maxlength="50">
					</div>
					<div class="col-md-2">
						<label class="control-label">Zip Code:</label>
							<input type="number" id="zip" name="zcode" onkeyup='validateInputField("zcode", "numeric")' value="<?php echo $customer['zip'];?>" placeholder="Zip Code" class="form-control">
							<?php echo form_error('zcode', '<div class="error">', '</div>'); ?>
							<div class="errorMessage" id="contact_error"></div>
					</div>
				
					<div class="col-md-2">
						<label class="control-label">Country :</label>
							<input type="text" placeholder="Country" id="country" value="<?php echo $customer['country'];?>" name="country" class="form-control" maxlength="50">
					</div>
				</div>
		    </div>
			<div class="row">
						<div class="col-sm-12 col-md-12"><h4 style="color:#A6CE39;font-weight:bold">Add New Visit Case</h4></div>
			</div>
			<div class="row">
				<div class="col-md-12">
									
					<div class="col-md-2">
					<label class="control-label">Contact Type:</label><br/>
					<select class="for-ui" id="ctype" name="contact_type">
					<option value="">Select Type</option>
					<option value="Visit">Visit</option>
					<option value="E-mail">E-mail</option>
					<option value="Phone Call">Phone Call</option>
					<option value="Fax">Fax</option>
					</select>
					</div>
												
					<div class="col-md-2">
						<label class="control-label">Visit Date:</label>
							<input readonly type="text" placeholder="Visit Date" value="<?php echo date('Y-m-d');?>" name="vcdate" class="form-control vcdate" maxlength="50">
					</div>
					<div class="col-md-2">
						<label class="control-label">Added By:</label>
							<input readonly type="text" name="contact" value="<?php echo $customer['user_name'];?>" placeholder="Agent Name" class="form-control user_name">
					</div>
				
					<div class="col-md-3">
						<label class="control-label">Visit Case Note:</label>
							<textarea type="text" placeholder="Vise Note" name="vcnote" class="form-control"><?php echo set_value('vcnote');?></textarea>
					</div>
					<div class="col-md-3">
							<label class="control-label"></label>
							<div class="btn_wrp">
								<div class="col-md-6"><input class="btn_greencl" type="submit" value="Save" /></div>
								<div class="col-md-6"><a href="<?php echo base_url().'admin/listcustomers';?>" class="btn_creamcl" >Cancel</a></div>
								<div class="cl"></div>
							</div>
					</div>
				</div>
			</div>				
				   <?php
                   echo form_close();
				   ?>
				   <?php endforeach; ?>
				    
                   </div><!---row--->
			 
           </div>
          </div>
          
          <div class="cl"></div>
          </div><!---innner-frm--->
       </div><!---customer-list-->
	 </div>
	 
<script language="javascript">

<!-- This script is based on the javascript code of Roman Feldblum (web.developer@programmer.net) -->
<!-- Original script : http://javascript.internet.com/forms/format-phone-number.html -->
<!-- Original script is revised by Eralper Yilmaz (http://www.eralper.com) -->
<!-- Revised script : http://www.kodyaz.com -->

var zChar = new Array(' ', '(', ')', '-', '.');
var maxphonelength = 14;
var phonevalue1;
var phonevalue2;
var cursorposition;

function ParseForNumber1(object){
phonevalue1 = ParseChar(object.value, zChar);
}
function ParseForNumber2(object){
phonevalue2 = ParseChar(object.value, zChar);
}

function backspacerUP(object,e) { 
if(e){ 
e = e 
} else {
e = window.event 
} 
if(e.which){ 
var keycode = e.which 
} else {
var keycode = e.keyCode 
}

ParseForNumber1(object)

if(keycode >= 48){
ValidatePhone(object)
}
}

function backspacerDOWN(object,e) { 
if(e){ 
e = e 
} else {
e = window.event 
} 
if(e.which){ 
var keycode = e.which 
} else {
var keycode = e.keyCode 
}
ParseForNumber2(object)
} 

function GetCursorPosition(){

var t1 = phonevalue1;
var t2 = phonevalue2;
var bool = false
for (i=0; i<t1.length; i++)
{
if (t1.substring(i,1) != t2.substring(i,1)) {
if(!bool) {
cursorposition=i
bool=true
}
}
}
}

function ValidatePhone(object){

var p = phonevalue1

p = p.replace(/[^\d]*/gi,"")

if (p.length < 4) {
object.value=p
} else if(p.length==4){
pp=p;
d4=p.indexOf('(')
d5=p.indexOf(')')
if(d4==-1){
pp="("+pp;
}
if(d5==-1){
pp=pp+")";
}
object.value = pp;
} else if(p.length>4 && p.length < 7){
p ="(" + p; 
l40=p.length;
p40=p.substring(0,4);
p40=p40+")"

p41=p.substring(4,l40);
pp=p40+p41;

object.value = pp; 

} else if(p.length >= 7){
p ="(" + p; 
l40=p.length;
p40=p.substring(0,4);
p40=p40+") "

p41=p.substring(4,l40);
pp=p40+p41;

l40 = pp.length;
p40 = pp.substring(0,9);
p40 = p40 + "-"

p41 = pp.substring(9,l40);
ppp = p40 + p41;

object.value = ppp.substring(0, maxphonelength);
}

GetCursorPosition()

if(cursorposition >= 0){
if (cursorposition == 0) {
cursorposition = 2
} else if (cursorposition <= 2) {
cursorposition = cursorposition + 1
} else if (cursorposition <= 5) {
cursorposition = cursorposition + 2
} else if (cursorposition == 6) {
cursorposition = cursorposition + 2
} else if (cursorposition == 7) {
cursorposition = cursorposition + 4
e1=object.value.indexOf(')')
e2=object.value.indexOf('-')
if (e1>-1 && e2>-1){
if (e2-e1 == 4) {
cursorposition = cursorposition - 1
}
}
} else if (cursorposition < 11) {
cursorposition = cursorposition + 4
} else if (cursorposition == 11) {
cursorposition = cursorposition + 1
} else if (cursorposition >= 12) {
cursorposition = cursorposition
}

var txtRange = object.createTextRange();
txtRange.moveStart( "character", cursorposition);
txtRange.moveEnd( "character", cursorposition - object.value.length);
txtRange.select();
}

}

function ParseChar(sStr, sChar)
{
if (sChar.length == null) 
{
zChar = new Array(sChar);
}
else zChar = sChar;

for (i=0; i<zChar.length; i++)
{
sNewStr = "";

var iStart = 0;
var iEnd = sStr.indexOf(sChar[i]);

while (iEnd != -1)
{
sNewStr += sStr.substring(iStart, iEnd);
iStart = iEnd + 1;
iEnd = sStr.indexOf(sChar[i], iStart);
}
sNewStr += sStr.substring(sStr.lastIndexOf(sChar[i]) + 1, sStr.length);

sStr = sNewStr;
}

return sNewStr;
}
</script>	 
	 