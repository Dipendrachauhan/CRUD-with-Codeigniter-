<?php defined('BASEPATH') OR exit('No direct script access allowed.');

if(!function_exists('checkSession'))
{
	function checkSessionsa(){ 
		$CI =& get_instance();
		if(!isset($CI->session->userdata['user_id']))
		{
			redirect('user/login');
		}
	}
}
