<?php
$bredcrembs = bredcrembs();
$uridata = str_replace("_", "   ", $bredcrembs['method']);
?>
<ol class="breadcrumb">

    <li><a href="<?php echo base_url() . 'admin/dashboard'; ?>"><i class="fa fa-dashboard"></i> Home</a></li>
    <li class="active"><?php echo ucwords($uridata); ?></li>
</ol>

