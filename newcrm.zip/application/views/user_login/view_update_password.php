<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html>
  <head>
    <title>CRM | <?php echo $title;?></title>
    <meta charset="utf-8">
	<meta name="format-detection" content="telephone=no">
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />

	<!---css----->
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/style-sheet.css"/>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/font/styles-font-calibri.css"/>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/bootstrap-3.3.6-dist/css/bootstrap.css"/>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/font-awesome-4.5.0/css/font-awesome.css"/>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/styles-nav.css"/>

	<!---css end----->

	<!--script--->
	<script type="text/javascript" src="<?php echo base_url();?>assets/js/jquery-2.2.0.min.js"></script>
	<script type="text/javascript" src="<?php echo base_url();?>assets/js/script.js"></script>
	<script type="text/javascript" src="<?php echo base_url();?>assets/bootstrap-3.3.6-dist/js/bootstrap.js"></script>

</head>
  <body>
    <div class="login-page-wrp">
		<div class="row">	
			<div class="login-frm">
			<h2>Update Your Password</h2>
		
		<form action="<?php base_url() . '/user_login/update_password';?>" name="update_password" method="POST">  
				<div class="col-sm-12 form-group">
				  <label for="password">Email</label>
				  <?php if(isset($email_hash, $email_code)){?>
					<input type="hidden" value="<?php echo $email_hash;?>" name="email_hash">
					<input type="hidden" value="<?php echo $email_code;?>" name="email_code">
				  <?php } ?> 
					<input type="email" class="form-control" id="email" name="email" placeholder="Email" value="<?php  echo (isset($email)) ? $email : '';?>">
				</div>
				
				<div class="col-sm-12 form-group">
				  <label for="New_Password">New Password</label>
				  <input type="password" value="" name="new_password">
				</div>  
				
				<div class="col-sm-12 form-group">
				  <label for="cahnge_Password">Confirm Password</label>
				  <input type="password" value="" name="password_conf">
				</div>
				
				<div class="col-sm-12 form-group">
				 <input type="submit" class="submit" name="submit" value="Update My Password">
				</div>
		</form>	
				
				<?php					
						echo validation_errors('<p class="error">');
				?>
			    </div>
		  </div>
     </div>
  </body>
</html>