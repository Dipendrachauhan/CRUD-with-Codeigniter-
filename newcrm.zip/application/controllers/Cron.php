<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Cron extends CI_Controller {

public function crontest(){
			 $currnt_date = date('Y-m-d');
			//echo $currnt_date;
			$this->load->model("Admin_model");
			$data['followup_data'] = $this->Admin_model->crontest($currnt_date);
			
			$email_message = $this->load->view('template/emails/followup_email', $data,true);	
		
			$this->load->library('email');

			$this->email->from('dipendrasingh010@gmail.com', 'Dipendra');
			$this->email->to('office@windhamcourt.com'); 


			$this->email->subject('Followup customers list');
			$this->email->message($email_message)->set_mailtype('html');	

			$this->email->send();
			//date_default_timezone_set('Asia/Kolkata');
			//echo date_default_timezone_get();die;
			//echo date('y-m-d H-i-s');
           
	}
} 
?>