<?php

       $userdata="";

?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>CRM | <?php echo $title; ?></title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Main CSS -->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/custom.css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/back_end.custom.css">
	
	 <link rel="stylesheet" href="<?php echo base_url();?>assets/css/jquery-ui.css">
    <script src="<?php echo base_url();?>assets/js/jQuery-2.1.4.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/jquery-ui.js"></script>
	<script src="<?php echo base_url();?>assets/js/custom.js"></script>
	
	 <script src="<?php echo base_url();?>assets/js/customjs.js"></script>
  
    <script src="<?php echo base_url();?>assets/js/map.google.js"></script>
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    <script>
    var BASE_URL = '<?php echo base_url();?>';
    </script>
  </head>
  <body class="hold-transition skin-blue sidebar-mini">
    <div class="wrapper">

      <header class="main-header">

        <!-- Logo -->
<!--        <a href="<?php echo base_url().'manager/dashboard'; ?>" class="logo">
           mini logo for sidebar mini 50x50 pixels 
          <img src="<?php echo base_url();?>assets/img/logo.png"/>
        </a>-->
         <a href="#" class="logo">
          <!-- mini logo for sidebar mini 50x50 pixels -->
          <span class="logo-mini"><img src="<?php echo base_url();?>assets/img/logo.png"></span>
          <!-- logo for regular state and mobile devices -->
          <span class="logo-lg"><img width="150" height="70" src="<?php echo base_url();?>assets/img/logo.png"></span>
        </a>
        <!-- Header Navbar: style can be found in header.less -->
        <nav class="navbar navbar-static-top" role="navigation">
          <!-- Sidebar toggle button-->
          <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
            <span class="sr-only">Toggle navigation</span>
          </a>
          <!-- Navbar Right Menu -->
          <div class="navbar-custom-menu">
            <ul class="nav navbar-nav">
              <li class="dropdown user user-menu">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
				<?php if($user_role==1) { ?>
					<img src="<?php echo base_url().'uploads/profile/'. $photo;?>" class="user-image" alt="User Image">
				<?php } elseif($user_role==2) { if($photo=='avatar.png') { ?>
					<img src="<?php echo base_url().'assets/img/'. $photo;?>" class="user-image" alt="User Image">
				<?php } else { ?>
					<img src="<?php echo base_url().'uploads/profile/'. $photo;?>" class="user-image" alt="User Image">
				<?php } } else { ?>
					<img src="<?php echo base_url().'uploads/profile/'. $photo;?>" class="user-image" alt="User Image">
				<?php } ?>
                  <span class="hidden-xs">
                    <!--  Alexander Pierce-->
                     <?php echo ucfirst($first_name);?>
                  
                  </span>
                </a>
                <ul class="dropdown-menu">
                  <!-- User image -->
                  <li class="user-header">
						<?php if($user_role==1) { ?>
							<img src="<?php echo base_url().'uploads/profile/'. $photo;?>" class="img-circle" alt="User Image">
						<?php } elseif($user_role==2) { if($photo=='avatar.png') { ?>
							<img src="<?php echo base_url().'assets/img/'. $photo;?>" class="img-circle" alt="User Image">
						<?php } else { ?>
							<img src="<?php echo base_url().'uploads/profile/'. $photo;?>" class="img-circle" alt="User Image">
						<?php } } else { ?>
							<img src="<?php echo base_url().'uploads/profile/'. $photo;?>" class="img-circle" alt="User Image">
						<?php } ?>
                    <p>
                     <!-- Alexander Pierce - Web Developer-->
                     <?php echo ucfirst($first_name)?>
                      <small><!--Member since Nov. 2012--></small>
                    </p>
                  </li>
                  <!-- Menu Body -->
<!--                  <li class="user-body">
                    <div class="col-xs-4 text-center">
                      <a href="#">Followers</a>
                    </div>
                    <div class="col-xs-4 text-center">
                      <a href="#">Sales</a>
                    </div>
                    <div class="col-xs-4 text-center">
                      <a href="#">Friends</a>
                    </div>
                  </li>-->
                  <!-- Menu Footer-->
					<li class="user-footer " style=" background-color: #3C8DBC;">
						<div class="pull-left">
							
							<?php if($user_role==1) { ?>
								<a href="<?php echo base_url().'admin/edit_profile';?>" class="btn btn-default">Profile</a>
							<?php } elseif($user_role==2) { ?>
								<a href="<?php echo base_url().'manager/edit_profile';?>" class="btn btn-default">Profile</a>
							<?php }  else { ?>
								<a href="<?php echo base_url().'dispatcher/edit_profile';?>" class="btn btn-default">Profile</a>
							<?php } ?>
						</div>
						<div class="pull-right ">
							<a href="<?php echo base_url().'admin/logout';?>" class="btn btn-default">Sign Out</a>
						</div>
					</li>
					<li class="user-footer " style=" background-color: #3C8DBC;">
						<div class="pull-left">
							
							<?php if($user_role==1) { ?>
								<a href="<?php echo base_url().'admin/changepassword';?>" class="btn btn-default">Change Password</a>
							<?php } elseif($user_role==2) { ?>
								<a href="<?php echo base_url().'manager/changepassword';?>" class="btn btn-default">Change Password</a>
							<?php }  else { ?>
								<a href="<?php echo base_url().'dispatcher/changepassword';?>" class="btn btn-default">Change Password</a>
							<?php } ?>
						</div>
					</li>
                </ul>
              </li>
              <!-- Control Sidebar Toggle Button -->
             
            </ul>
          </div>

        </nav>
      </header>
        <div class="content-wrapper">
		
        <!-- Content Header (Page header) -->