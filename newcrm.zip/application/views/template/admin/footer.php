<footer class="bg_footer">
   <div class="container-fluid">
   <div class="col-lg-12">
     <p class="text-center">Copyright &copy; <?php echo date('Y') ;?> All Rights Reserved.</p>
   </div>
   </div>
 </footer>
</body>
</html>