<!DOCTYPE HTML>
<html>
<head>
<title>CRM | <?php echo $title; ?></title>
<meta charset="utf-8">
<meta name="format-detection" content="telephone=no">
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />

<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/style-sheet.css"/>
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/font/styles-font-calibri.css"/>
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/bootstrap-3.3.6-dist/css/bootstrap.css"/>
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/font-awesome-4.5.0/css/font-awesome.css"/>
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/styles-nav.css"/>
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/multiselect.css"/>
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/custom.css"/>
<link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/themes/smoothness/jquery-ui.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/css/jquery-ui.css">
   
<!-- old css -->

<!--<script type="text/javascript" src="<?php //echo base_url();?>assets/js/multipleselect1.js"></script>-->
<script type="text/javascript" src="<?php echo base_url();?>assets/js/multipleselect2.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/multipleselect3.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/script.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/bootstrap-3.3.6-dist/js/bootstrap.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/multiselect.js"></script>

<!-- Old scripts -->
 <script src="<?php echo base_url();?>assets/js/jquery-ui.js"></script>
 <script src="<?php echo base_url();?>assets/js/custom.js"></script>
  <script src="<?php echo base_url();?>assets/js/customjs.js"></script>
    <script>
    var BASE_URL = '<?php echo base_url();?>';
	
	  $(document).ready(function() { 
			$("#datepicker").datepicker({
			 dateFormat: "dd-mm-yy", 
			 minDate: 0,
                         showOn: "button",
                        buttonImage: "http://jqueryui.com/resources/demos/datepicker/images/calendar.gif",
                        buttonImageOnly: true
	   });
	   $("#datepicker1").datepicker({
			 dateFormat: "dd-mm-yy", 
			 minDate: 0,
                         showOn: "button",
                         buttonImage: "http://jqueryui.com/resources/demos/datepicker/images/calendar.gif",
                         buttonImageOnly: true
	   });   
	   });
	   
	   </script>
	   <script type="text/javascript">
  function capitalize(textboxid, str) {
      // string with alteast one character
      if (str && str.length >= 1)
      {       
          var firstChar = str.charAt(0);
          var remainingStr = str.slice(1);
          str = firstChar.toUpperCase() + remainingStr;
      }
      document.getElementById(textboxid).value = str;
  }
  </script>
	   
</head>
 <body>
    <header>
	
  <div class="logo-searchboxwrp">
   <div class="container-fluid">
    <div class="row">
     <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
       <div class="logo"><a href="<?php if($user_role == 1) { echo base_url().'admin/listcustomers'; } else if($user_role == 2) { echo base_url().'admin/listcustomers';}?>" ><img class="img-responsive" src="<?php echo base_url();?>assets/img/logo.png" alt="crm logo"/></a></div><!--logo--->
     </div>
     <div class="col-lg-6 col-md-9 col-sm-9 col-xs-12 pull-right"> 
        <div class="search_crmuwrp">
         <div class="search_inpcus">
		   <!-- <form id="searchcustomer" role="form" action="<?php echo base_url().'admin/searchcustomer';?>">
			  <div class="form-group inp_search">				
				<input autocomplete="off" name="search" type="text" value="<?php if(isset($_GET['search'])){ echo $_GET['search'];} ?>" class="form-control search" placeholder="Search Customers" id="search">
				<button class="search_btn"><i class="fa fa-search"></i></button>
				<div id="result1"></div>
			  </div>
            </form>--> 
			
        <div class="crm_userlogin">
           <ul class="top-right">           
			   <li class="dropdown link">
					<a class="profilebox" href="<?php echo base_url().'user_login/logout';?>" aria-expanded="true"><i class="fa fa-user font-asom-marright"></i><strong> <i class="fa falist fa-power-off"></i> Logout &nbsp;</strong>
					</a>
			   </li>
			</ul>
        </div><!--crm_userlogin--> 
		  
		   <div class="cl"></div>
		 </div><!---search_inpcus--->

        </div><!---search_crmuwrp--->
     </div>
    </div>
   </div>
  
  </div><!--logo-searchboxwrp-->

	  <?php echo $menu; ?>
	  
 </header>
