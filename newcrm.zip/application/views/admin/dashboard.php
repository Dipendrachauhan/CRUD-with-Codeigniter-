<?php 
if(isset($this->session->userdata['email_id'])) {
	//echo "hello dashboard"; die;
	//redirect('admin/dashboard');
}
else{
    redirect('admin/login');
}

?>
        <!-- Main content -->
        <section class="content">
          <!-- Info boxes -->
          <div class="row">
            <div class="col-md-3 col-sm-6 col-xs-12" style="width: 33.3%;">
              <div class="info-box">
                <span class="info-box-icon bg-aqua"><i class="fa fa-home"></i></span>
                <div class="info-box-content">
                  <small></small></span>
                </div><!-- /.info-box-content -->
              </div><!-- /.info-box -->
            </div><!-- /.col -->
            <div class="col-md-3 col-sm-6 col-xs-12" style="width: 33.3%;">
              <div class="info-box">
                <span class="info-box-icon bg-red"><i class="fa fa-user-plus"></i></span>
                
              </div><!-- /.info-box -->
            </div><!-- /.col -->

            <!-- fix for small devices only -->
            <div class="clearfix visible-sm-block"></div>

            <div class="col-md-3 col-sm-6 col-xs-12" style="width: 33.3%;">
              <div class="info-box">
                <span class="info-box-icon bg-green"><i class="fa fa-usd"></i></span>
                
              </div>
            </div>

          </div>
         
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->



