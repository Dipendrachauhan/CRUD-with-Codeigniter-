$(document).ready(function() {
// Datepicker Popups calender to Choose date.
$(function() {
$("#start_date").datepicker({
	 dateFormat: "yy-mm-dd",
	  minDate: 0,
	  beforeShowDay: function(date) {
	  var day = date.getDay();
	  return [day == 0,''];
    },
	onSelect: function(date) {
            var someDate = new Date(date);
			var numberOfDaysToAdd = 6;
			someDate.setDate(someDate.getDate() + numberOfDaysToAdd);
			var someFormattedDate = someDate.getFullYear() + '-' + ('0' + (someDate.getMonth()+1)).slice(-2) + '-' +('0' + someDate.getDate()).slice(-2) ;
			
			$("#end_date").val(someFormattedDate)
        },
});

});
});




			